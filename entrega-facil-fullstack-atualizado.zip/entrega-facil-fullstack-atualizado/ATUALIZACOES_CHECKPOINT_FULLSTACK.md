# Checkpoint Full-stack — Entrega Fácil

Este pacote consolida as integrações feitas durante a migração do protótipo para uma aplicação React + Express + MySQL.

## O que foi concluído

- Autenticação real com bcrypt + JWT.
- `GET /api/auth/me` para restaurar a sessão após F5.
- Atualização e exclusão lógica do perfil.
- Condomínios carregados pelo MySQL.
- Validação de moradia pelo banco.
- Correção de condomínio/bloco/apartamento sem recriar a conta.
- Validação flexível de bloco/torre: `1`, `Torre 1`, `torre1` e `Bloco 1` podem corresponder à unidade canônica cadastrada.
- Habilitação real de vendedor em `perfis_vendedor`.
- CRUD de produtos/serviços no MySQL.
- Catálogo carregado pela API.
- Pedidos persistidos no MySQL com baixa/restauração de estoque.
- Fluxo de status do pedido pelo vendedor.
- Confirmação de recebimento pelo comprador.
- Pagamento somente na entrega.
- Avaliações comprador ↔ vendedor persistidas.
- Ratings de usuário/produto atualizados no banco.
- Dashboard/telas passam a consumir produtos e pedidos reais.
- Mocks de usuários, produtos, pedidos e unidades válidas removidos do fluxo.
- Script `typecheck` adicionado ao frontend.

## Rotas adicionadas

### Auth
- POST `/api/auth/register`
- POST `/api/auth/login`
- GET `/api/auth/me`
- PATCH `/api/auth/me`
- DELETE `/api/auth/me`

### Moradia
- POST `/api/residents/validate`
- PUT `/api/residents/address`

### Vendedor
- PUT `/api/seller/profile`

### Produtos
- GET `/api/products`
- GET `/api/products/:id`
- POST `/api/products`
- PUT `/api/products/:id`
- DELETE `/api/products/:id`

### Pedidos
- GET `/api/orders`
- POST `/api/orders`
- PATCH `/api/orders/:id/status`
- POST `/api/orders/:id/confirm-receipt`
- POST `/api/orders/:id/ratings`

## Validações executadas neste pacote

- Backend: TypeScript `tsc --noEmit` passou.
- Backend: compilação `tsc` passou e gerou `dist` durante o teste.
- Backend: smoke test da API respondeu `200 /api` e `401` esperado em rota privada sem JWT.
- Frontend: TypeScript `tsc --noEmit` passou.

O build Vite não foi executado no ambiente de preparação porque o ZIP original continha os binários nativos do Rolldown para Windows, enquanto o ambiente de preparação é Linux. No Windows do projeto, após `pnpm install`, execute `pnpm build` normalmente.

## Teste recomendado no Windows

Backend:

```powershell
cd BackEnd
npm install
npm run typecheck
npm run dev
```

Frontend:

```powershell
cd "Programa baseado em telas-entrega segura"
pnpm install
pnpm typecheck
pnpm build
pnpm dev
```

Teste funcional sugerido:

1. Criar conta.
2. Validar uma unidade válida.
3. Fazer logout/login e atualizar a página para confirmar restauração da sessão.
4. Habilitar vendedor.
5. Cadastrar produto.
6. Entrar com outro morador do mesmo condomínio.
7. Comprar o produto.
8. Entrar como vendedor e avançar os status até `delivered`.
9. Comprador confirma recebimento e avalia vendedor.
10. Vendedor avalia comprador.

## Correção de carregamento independente do marketplace

O `refreshMarketplace` foi alterado para usar `Promise.allSettled`. Assim, uma falha na API de pedidos não impede o catálogo de receber os produtos, e vice-versa.

A API de produtos continua intencionalmente restrita ao condomínio do usuário autenticado. Para validar visibilidade entre duas contas, ambas precisam possuir o mesmo `condominio_id`, e o produto precisa estar com `disponivel = 1`.
