# Entrega Fácil

Marketplace interno para moradores de condomínios, desenvolvido como TCC do curso Técnico em Desenvolvimento de Sistemas do SENAI.

## Stack

- Frontend: React 19 + TypeScript + Vite + Tailwind CSS
- Backend: Node.js + Express + TypeScript
- Banco de dados: MySQL
- Segurança: bcrypt para senhas e JWT para autenticação

## Estado da integração

A versão deste pacote já usa APIs reais para:

- cadastro e login;
- restauração da sessão com `GET /api/auth/me`;
- condomínios;
- validação de moradia e correção de bloco/apartamento;
- habilitação e perfil de vendedor;
- catálogo e CRUD de produtos/serviços;
- criação e acompanhamento de pedidos;
- atualização de status pelo vendedor;
- confirmação de recebimento;
- avaliações entre comprador e vendedor;
- atualização e exclusão lógica da conta.

Os antigos mocks de usuários, produtos, pedidos e unidades válidas foram removidos do fluxo da aplicação.

## Executar

### Backend

```powershell
cd BackEnd
npm install
npm run typecheck
npm run dev
```

### Frontend

```powershell
cd "Programa baseado em telas-entrega segura"
pnpm install
pnpm typecheck
pnpm dev
```

Frontend: `http://localhost:8443`  
Backend: `http://localhost:3000/api`

Consulte `BackEnd/README_SETUP.md` para configuração do MySQL e `.env`.
