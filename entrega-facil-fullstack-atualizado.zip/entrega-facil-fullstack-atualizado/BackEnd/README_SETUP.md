# Entrega Fácil - Backend

API em Node.js + Express + TypeScript + MySQL.

## Instalação

```powershell
npm install
```

## Banco de dados

Crie o usuário do aplicativo no MySQL com uma senha local forte:

```sql
CREATE DATABASE IF NOT EXISTS entrega_facil
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

CREATE USER IF NOT EXISTS 'entrega_app'@'localhost'
  IDENTIFIED BY 'SUA_SENHA_LOCAL';

GRANT ALL PRIVILEGES ON entrega_facil.* TO 'entrega_app'@'localhost';
FLUSH PRIVILEGES;
```

Depois execute, nessa ordem:

1. `sql/schema.sql`
2. `sql/seed.sql`

O seed cadastra os condomínios e unidades usadas na demonstração.

## Variáveis de ambiente

Copie `.env.example` para `.env` e ajuste a senha e o JWT secret.

```env
PORT=3000
DB_HOST=127.0.0.1
DB_PORT=3306
DB_NAME=entrega_facil
DB_USER=entrega_app
DB_PASSWORD=SUA_SENHA_LOCAL
JWT_SECRET=UMA_CHAVE_LOCAL_GRANDE_E_ALEATORIA
FRONTEND_ORIGIN=http://localhost:8443
```

## Executar

```powershell
npm run typecheck
npm run dev
```

Teste `http://localhost:3000/api/health`. O campo `database` deve ser `connected`.

## Rotas principais

- `GET /api/health`
- `GET /api/condominiums`
- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/auth/me`
- `PATCH /api/auth/me`
- `DELETE /api/auth/me`
- `POST /api/residents/validate`
- `PUT /api/residents/address`
- `PUT /api/seller/profile`
- `GET /api/products`
- `POST /api/products`
- `PUT /api/products/:id`
- `DELETE /api/products/:id`
- `GET /api/orders`
- `POST /api/orders`
- `PATCH /api/orders/:id/status`
- `POST /api/orders/:id/confirm-receipt`
- `POST /api/orders/:id/ratings`

As rotas privadas usam `Authorization: Bearer <JWT>`.
