USE entrega_facil;

INSERT INTO condominios (id, nome, endereco, hora_inicio, hora_fim, dias_permitidos)
VALUES
  (1, 'Condomínio Solar', 'Rua das Flores, 100 — Bairro Jardim', 8, 22, JSON_ARRAY(1,2,3,4,5,6)),
  (2, 'Residencial Parque Verde', 'Av. das Palmeiras, 250 — Centro', 9, 21, JSON_ARRAY(1,2,3,4,5))
ON DUPLICATE KEY UPDATE
  nome = VALUES(nome),
  endereco = VALUES(endereco),
  hora_inicio = VALUES(hora_inicio),
  hora_fim = VALUES(hora_fim),
  dias_permitidos = VALUES(dias_permitidos);

INSERT INTO unidades_condominio (condominio_id, bloco, apartamento, ativo)
VALUES
  (1, 'A', '201', TRUE),
  (1, 'B', '105', TRUE),
  (1, 'C', '304', TRUE),
  (2, 'Torre 1', '703', TRUE),
  (2, 'Torre 2', '405', TRUE)
ON DUPLICATE KEY UPDATE ativo = VALUES(ativo);
