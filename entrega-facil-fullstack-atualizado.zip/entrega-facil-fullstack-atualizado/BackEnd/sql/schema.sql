CREATE DATABASE IF NOT EXISTS entrega_facil
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE entrega_facil;

CREATE TABLE IF NOT EXISTS condominios (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(150) NOT NULL,
    endereco VARCHAR(255) NOT NULL,
    hora_inicio TINYINT UNSIGNED NOT NULL,
    hora_fim TINYINT UNSIGNED NOT NULL,
    dias_permitidos JSON NOT NULL,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS unidades_condominio (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    condominio_id BIGINT UNSIGNED NOT NULL,
    bloco VARCHAR(50) NOT NULL,
    apartamento VARCHAR(30) NOT NULL,
    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    UNIQUE (condominio_id, bloco, apartamento),
    CONSTRAINT fk_unidade_condominio FOREIGN KEY (condominio_id) REFERENCES condominios(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS usuarios (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(150) NOT NULL,
    email VARCHAR(200) NOT NULL UNIQUE,
    cpf VARCHAR(14) NOT NULL UNIQUE,
    senha_hash VARCHAR(255) NOT NULL,
    condominio_id BIGINT UNSIGNED NOT NULL,
    bloco VARCHAR(50) NOT NULL,
    apartamento VARCHAR(30) NOT NULL,
    papel ENUM('buyer', 'both') NOT NULL DEFAULT 'buyer',
    validado BOOLEAN NOT NULL DEFAULT FALSE,
    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    rating DECIMAL(3,2) NOT NULL DEFAULT 0,
    total_ratings INT UNSIGNED NOT NULL DEFAULT 0,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_usuario_condominio FOREIGN KEY (condominio_id) REFERENCES condominios(id)
);

CREATE TABLE IF NOT EXISTS perfis_vendedor (
    usuario_id BIGINT UNSIGNED PRIMARY KEY,
    nome_negocio VARCHAR(150) NOT NULL,
    categoria VARCHAR(80) NOT NULL,
    descricao TEXT,
    telefone VARCHAR(30),
    horario_atendimento VARCHAR(150),
    CONSTRAINT fk_perfil_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS produtos (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    vendedor_id BIGINT UNSIGNED NOT NULL,
    condominio_id BIGINT UNSIGNED NOT NULL,
    nome VARCHAR(150) NOT NULL,
    descricao TEXT NOT NULL,
    preco DECIMAL(10,2) NOT NULL,
    custo DECIMAL(10,2),
    estoque INT UNSIGNED NOT NULL DEFAULT 0,
    categoria VARCHAR(80) NOT NULL,
    imagem_url VARCHAR(500),
    tipo ENUM('product', 'service') NOT NULL DEFAULT 'product',
    disponivel BOOLEAN NOT NULL DEFAULT TRUE,
    rating DECIMAL(3,2) NOT NULL DEFAULT 0,
    total_ratings INT UNSIGNED NOT NULL DEFAULT 0,
    duracao VARCHAR(50),
    hora_inicio TIME,
    hora_fim TIME,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_produto_vendedor FOREIGN KEY (vendedor_id) REFERENCES usuarios(id),
    CONSTRAINT fk_produto_condominio FOREIGN KEY (condominio_id) REFERENCES condominios(id)
);

CREATE TABLE IF NOT EXISTS produto_dias_disponiveis (
    produto_id BIGINT UNSIGNED NOT NULL,
    dia_semana TINYINT UNSIGNED NOT NULL,
    PRIMARY KEY (produto_id, dia_semana),
    CONSTRAINT fk_dia_produto FOREIGN KEY (produto_id) REFERENCES produtos(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS pedidos (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    comprador_id BIGINT UNSIGNED NOT NULL,
    vendedor_id BIGINT UNSIGNED NOT NULL,
    condominio_id BIGINT UNSIGNED NOT NULL,
    total DECIMAL(10,2) NOT NULL,
    status ENUM('pending','confirmed','preparing','ready','delivering','delivered','cancelled') NOT NULL DEFAULT 'pending',
    pagamento_status ENUM('pending','approved') NOT NULL DEFAULT 'pending',
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    recebimento_confirmado_em DATETIME NULL,
    CONSTRAINT fk_pedido_comprador FOREIGN KEY (comprador_id) REFERENCES usuarios(id),
    CONSTRAINT fk_pedido_vendedor FOREIGN KEY (vendedor_id) REFERENCES usuarios(id),
    CONSTRAINT fk_pedido_condominio FOREIGN KEY (condominio_id) REFERENCES condominios(id)
);

CREATE TABLE IF NOT EXISTS itens_pedido (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    pedido_id BIGINT UNSIGNED NOT NULL,
    produto_id BIGINT UNSIGNED NOT NULL,
    quantidade INT UNSIGNED NOT NULL,
    preco_unitario DECIMAL(10,2) NOT NULL,
    data_agendada DATE NULL,
    hora_agendada TIME NULL,
    CONSTRAINT fk_item_pedido FOREIGN KEY (pedido_id) REFERENCES pedidos(id) ON DELETE CASCADE,
    CONSTRAINT fk_item_produto FOREIGN KEY (produto_id) REFERENCES produtos(id)
);

CREATE TABLE IF NOT EXISTS avaliacoes (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    pedido_id BIGINT UNSIGNED NOT NULL,
    avaliador_id BIGINT UNSIGNED NOT NULL,
    avaliado_id BIGINT UNSIGNED NOT NULL,
    papel_avaliador ENUM('buyer','seller') NOT NULL,
    nota TINYINT UNSIGNED NOT NULL,
    comentario TEXT,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_avaliacao_nota CHECK (nota BETWEEN 1 AND 5),
    CONSTRAINT uq_avaliacao_pedido_papel UNIQUE (pedido_id, papel_avaliador),
    CONSTRAINT fk_avaliacao_pedido FOREIGN KEY (pedido_id) REFERENCES pedidos(id),
    CONSTRAINT fk_avaliacao_avaliador FOREIGN KEY (avaliador_id) REFERENCES usuarios(id),
    CONSTRAINT fk_avaliacao_avaliado FOREIGN KEY (avaliado_id) REFERENCES usuarios(id)
);

CREATE TABLE IF NOT EXISTS logs_auditoria (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    usuario_id BIGINT UNSIGNED NULL,
    acao VARCHAR(100) NOT NULL,
    entidade VARCHAR(100),
    entidade_id VARCHAR(100),
    dados_resumidos JSON,
    ip VARCHAR(45),
    resultado VARCHAR(30),
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_log_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL
);
