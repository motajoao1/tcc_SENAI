import { Router } from 'express';
import { sellerController } from '../controllers/seller.controller.js';
import { authMiddleware } from '../middlewares/auth.middleware.js';

export const sellerRouter = Router();

sellerRouter.put('/profile', authMiddleware, sellerController.upsertProfile);
