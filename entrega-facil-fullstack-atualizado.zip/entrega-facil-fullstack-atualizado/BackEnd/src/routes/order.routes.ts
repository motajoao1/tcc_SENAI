import { Router } from 'express';
import { orderController } from '../controllers/order.controller.js';
import { authMiddleware } from '../middlewares/auth.middleware.js';

export const orderRouter = Router();
orderRouter.use(authMiddleware);
orderRouter.get('/', orderController.list);
orderRouter.post('/', orderController.create);
orderRouter.patch('/:id/status', orderController.updateStatus);
orderRouter.post('/:id/confirm-receipt', orderController.confirmReceipt);
orderRouter.post('/:id/ratings', orderController.rate);
