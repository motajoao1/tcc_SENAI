import { Router } from 'express';
import { db } from '../config/database.js';

export const condominiumsRouter = Router();

interface CondominiumRow {
  id: number;
  nome: string;
  endereco: string;
  hora_inicio: number;
  hora_fim: number;
  dias_permitidos: string | number[];
}

condominiumsRouter.get('/', async (_req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT
        id,
        nome,
        endereco,
        hora_inicio,
        hora_fim,
        dias_permitidos
      FROM condominios
      ORDER BY nome
    `);

    const condominiums = (rows as CondominiumRow[]).map((row) => ({
      ...row,

      dias_permitidos:
        typeof row.dias_permitidos === 'string'
          ? JSON.parse(row.dias_permitidos)
          : row.dias_permitidos,
    }));

    return res.status(200).json(condominiums);
  } catch (error) {
    console.error('Erro ao buscar condomínios:', error);

    return res.status(500).json({
      error: 'Não foi possível carregar os condomínios.',
    });
  }
});