import { Router } from 'express';
import { db } from '../config/database.js';

export const healthRouter = Router();

healthRouter.get('/', async (_req, res) => {
  try {
    await db.query('SELECT 1');

    return res.status(200).json({
      status: 'ok',
      application: 'Entrega Fácil API',
      database: 'connected',
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error('Falha no health check:', error);

    return res.status(503).json({
      status: 'error',
      application: 'Entrega Fácil API',
      database: 'disconnected',
      timestamp: new Date().toISOString(),
    });
  }
});
