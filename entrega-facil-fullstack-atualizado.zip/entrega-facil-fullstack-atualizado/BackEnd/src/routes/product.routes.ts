import { Router } from 'express';
import { productController } from '../controllers/product.controller.js';
import { authMiddleware } from '../middlewares/auth.middleware.js';

export const productRouter = Router();

productRouter.use(authMiddleware);
productRouter.get('/', productController.list);
productRouter.get('/:id', productController.get);
productRouter.post('/', productController.create);
productRouter.put('/:id', productController.update);
productRouter.delete('/:id', productController.remove);
