import { Router } from 'express';

import { residentController } from '../controllers/resident.controller.js';
import { authMiddleware } from '../middlewares/auth.middleware.js';

export const residentsRouter = Router();

residentsRouter.post(
  '/validate',
  authMiddleware,
  residentController.validate,
);

residentsRouter.put(
  '/address',
  authMiddleware,
  residentController.updateAddress,
);