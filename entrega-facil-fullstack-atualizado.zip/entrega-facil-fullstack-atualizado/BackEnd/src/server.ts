import express from 'express';
import cors from 'cors';
import 'dotenv/config';

import { authRouter } from './routes/auth.routes.js';
import { condominiumsRouter } from './routes/condominiums.routes.js';
import { healthRouter } from './routes/health.routes.js';
import { orderRouter } from './routes/order.routes.js';
import { productRouter } from './routes/product.routes.js';
import { residentsRouter } from './routes/residents.routes.js';
import { sellerRouter } from './routes/seller.routes.js';

const app = express();
const PORT = Number(process.env.PORT ?? 3000);
const FRONTEND_ORIGIN = process.env.FRONTEND_ORIGIN ?? 'http://localhost:8443';

app.use(
  cors({
    origin: FRONTEND_ORIGIN,
    credentials: true,
  }),
);
app.use(express.json());

app.get('/api', (_req, res) => {
  res.json({
    application: 'Entrega Fácil API',
    version: '1.0.0',
    status: 'running',
  });
});

app.use('/api/health', healthRouter);
app.use('/api/condominiums', condominiumsRouter);
app.use('/api/auth', authRouter);
app.use('/api/residents', residentsRouter);
app.use('/api/seller', sellerRouter);
app.use('/api/products', productRouter);
app.use('/api/orders', orderRouter);

app.use((_req, res) => {
  res.status(404).json({ error: 'Rota não encontrada' });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log('');
  console.log('====================================');
  console.log('      Entrega Fácil - Backend');
  console.log('====================================');
  console.log(`API:    http://localhost:${PORT}/api`);
  console.log(`Health: http://localhost:${PORT}/api/health`);
  console.log(`CORS:   ${FRONTEND_ORIGIN}`);
  console.log('====================================');
  console.log('');
});
