import type { Response } from 'express';
import type { AuthenticatedRequest } from '../middlewares/auth.middleware.js';
import { sellerProfileSchema } from '../schemas/seller.schema.js';
import { sellerService } from '../services/seller.service.js';

export const sellerController = {
  async upsertProfile(req: AuthenticatedRequest, res: Response) {
    if (!req.userId) return res.status(401).json({ error: 'Usuário não autenticado.' });

    const parsed = sellerProfileSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({
        error: 'Dados de vendedor inválidos.',
        details: parsed.error.flatten(),
      });
    }

    try {
      return res.status(200).json({
        user: await sellerService.upsertProfile(req.userId, parsed.data),
      });
    } catch (error) {
      if (error instanceof Error && error.message === 'USER_NOT_VALIDATED') {
        return res.status(403).json({ error: 'Valide sua moradia antes de habilitar vendas.' });
      }
      console.error('Erro ao habilitar vendedor:', error);
      return res.status(500).json({ error: 'Não foi possível habilitar a conta de vendedor.' });
    }
  },
};
