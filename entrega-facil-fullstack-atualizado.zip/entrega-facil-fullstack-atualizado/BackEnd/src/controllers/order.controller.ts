import type { Response } from 'express';
import type { AuthenticatedRequest } from '../middlewares/auth.middleware.js';
import { createOrderSchema, orderStatusSchema, ratingSchema } from '../schemas/order.schema.js';
import { orderService } from '../services/order.service.js';

function parseId(value: string | string[] | undefined) {
  const raw = Array.isArray(value) ? value[0] : value;
  const id = Number(raw);
  return Number.isInteger(id) && id > 0 ? id : null;
}

function serviceError(res: Response, error: unknown) {
  const message = error instanceof Error ? error.message : '';
  const known: Record<string, [number, string]> = {
    USER_NOT_VALIDATED: [403, 'Valide sua moradia antes de realizar pedidos.'],
    PRODUCT_UNAVAILABLE: [409, 'Um dos produtos não está mais disponível.'],
    WRONG_CONDOMINIUM: [403, 'O produto não pertence ao seu condomínio.'],
    INSUFFICIENT_STOCK: [409, 'Estoque insuficiente para um dos itens.'],
    MULTIPLE_SELLERS: [400, 'O carrinho deve conter itens de apenas um vendedor.'],
    SELF_PURCHASE: [400, 'Você não pode comprar seu próprio anúncio.'],
    INVALID_SCHEDULE: [400, 'A data ou horário selecionado não está disponível.'],
    ORDER_NOT_FOUND: [404, 'Pedido não encontrado.'],
    FORBIDDEN: [403, 'Você não tem permissão para esta operação.'],
    INVALID_STATUS_TRANSITION: [409, 'Esta mudança de status não é permitida.'],
    RECEIPT_NOT_ALLOWED: [409, 'O recebimento não pode ser confirmado neste momento.'],
    RATING_NOT_ALLOWED: [409, 'Este pedido ainda não pode ser avaliado.'],
    RATING_ALREADY_EXISTS: [409, 'Este pedido já foi avaliado por você.'],
  };
  const knownError = known[message];
  if (knownError) return res.status(knownError[0]).json({ error: knownError[1] });
  console.error('Erro em pedidos:', error);
  return res.status(500).json({ error: 'Não foi possível concluir a operação do pedido.' });
}

export const orderController = {
  async list(req: AuthenticatedRequest, res: Response) {
    if (!req.userId) return res.status(401).json({ error: 'Usuário não autenticado.' });
    try {
      return res.status(200).json(await orderService.listForUser(req.userId));
    } catch (error) {
      return serviceError(res, error);
    }
  },

  async create(req: AuthenticatedRequest, res: Response) {
    if (!req.userId) return res.status(401).json({ error: 'Usuário não autenticado.' });
    const parsed = createOrderSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: 'Dados do pedido inválidos.', details: parsed.error.flatten() });
    }
    try {
      return res.status(201).json({ order: await orderService.create(req.userId, parsed.data) });
    } catch (error) {
      return serviceError(res, error);
    }
  },

  async updateStatus(req: AuthenticatedRequest, res: Response) {
    if (!req.userId) return res.status(401).json({ error: 'Usuário não autenticado.' });
    const id = parseId(req.params.id);
    if (!id) return res.status(400).json({ error: 'Pedido inválido.' });
    const parsed = orderStatusSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'Status inválido.' });
    try {
      return res.status(200).json({
        order: await orderService.updateStatus(req.userId, id, parsed.data.status),
      });
    } catch (error) {
      return serviceError(res, error);
    }
  },

  async confirmReceipt(req: AuthenticatedRequest, res: Response) {
    if (!req.userId) return res.status(401).json({ error: 'Usuário não autenticado.' });
    const id = parseId(req.params.id);
    if (!id) return res.status(400).json({ error: 'Pedido inválido.' });
    try {
      return res.status(200).json({ order: await orderService.confirmReceipt(req.userId, id) });
    } catch (error) {
      return serviceError(res, error);
    }
  },

  async rate(req: AuthenticatedRequest, res: Response) {
    if (!req.userId) return res.status(401).json({ error: 'Usuário não autenticado.' });
    const id = parseId(req.params.id);
    if (!id) return res.status(400).json({ error: 'Pedido inválido.' });
    const parsed = ratingSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'Avaliação inválida.' });
    try {
      return res.status(200).json({ order: await orderService.rate(req.userId, id, parsed.data) });
    } catch (error) {
      return serviceError(res, error);
    }
  },
};
