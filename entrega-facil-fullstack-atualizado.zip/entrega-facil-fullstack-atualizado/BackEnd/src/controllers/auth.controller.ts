import type { Request, Response } from 'express';

import type { AuthenticatedRequest } from '../middlewares/auth.middleware.js';
import {
  loginSchema,
  registerSchema,
  updateCurrentUserSchema,
} from '../schemas/auth.schema.js';
import { authService } from '../services/auth.service.js';

export const authController = {
  async register(req: Request, res: Response) {
    const parsed = registerSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({
        error: 'Dados de cadastro inválidos.',
        details: parsed.error.flatten(),
      });
    }

    try {
      return res.status(201).json(await authService.register(parsed.data));
    } catch (error) {
      if (error instanceof Error && error.message === 'EMAIL_OR_CPF_EXISTS') {
        return res.status(409).json({ error: 'E-mail ou CPF já cadastrado.' });
      }
      console.error('Erro no cadastro:', error);
      return res.status(500).json({ error: 'Não foi possível criar a conta.' });
    }
  },

  async login(req: Request, res: Response) {
    const parsed = loginSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: 'E-mail ou senha inválidos.' });
    }

    try {
      const result = await authService.login(parsed.data);
      if (!result) return res.status(401).json({ error: 'E-mail ou senha incorretos.' });
      return res.status(200).json(result);
    } catch (error) {
      console.error('Erro no login:', error);
      return res.status(500).json({ error: 'Não foi possível realizar o login.' });
    }
  },

  async me(req: AuthenticatedRequest, res: Response) {
    if (!req.userId) return res.status(401).json({ error: 'Usuário não autenticado.' });
    const user = await authService.me(req.userId);
    if (!user) return res.status(401).json({ error: 'Sessão inválida.' });
    return res.status(200).json({ user });
  },

  async updateMe(req: AuthenticatedRequest, res: Response) {
    if (!req.userId) return res.status(401).json({ error: 'Usuário não autenticado.' });
    const parsed = updateCurrentUserSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: 'Dados de perfil inválidos.', details: parsed.error.flatten() });
    }
    try {
      return res.status(200).json({ user: await authService.updateMe(req.userId, parsed.data) });
    } catch (error) {
      console.error('Erro ao atualizar perfil:', error);
      return res.status(500).json({ error: 'Não foi possível atualizar o perfil.' });
    }
  },

  async deleteMe(req: AuthenticatedRequest, res: Response) {
    if (!req.userId) return res.status(401).json({ error: 'Usuário não autenticado.' });
    try {
      await authService.deleteMe(req.userId);
      return res.status(204).send();
    } catch (error) {
      console.error('Erro ao excluir conta:', error);
      return res.status(500).json({ error: 'Não foi possível excluir a conta.' });
    }
  },
};
