import type { Response } from 'express';
import type { AuthenticatedRequest } from '../middlewares/auth.middleware.js';
import { productInputSchema } from '../schemas/product.schema.js';
import { productService } from '../services/product.service.js';

function parseId(value: string | string[] | undefined): number | null {
  const raw = Array.isArray(value) ? value[0] : value;
  const id = Number(raw);
  return Number.isInteger(id) && id > 0 ? id : null;
}

export const productController = {
  async list(req: AuthenticatedRequest, res: Response) {
    if (!req.userId) return res.status(401).json({ error: 'Usuário não autenticado.' });
    try {
      return res.status(200).json(await productService.listForUser(req.userId));
    } catch (error) {
      console.error('Erro ao listar produtos:', error);
      return res.status(500).json({ error: 'Não foi possível carregar os produtos.' });
    }
  },

  async get(req: AuthenticatedRequest, res: Response) {
    if (!req.userId) return res.status(401).json({ error: 'Usuário não autenticado.' });
    const id = parseId(req.params.id);
    if (!id) return res.status(400).json({ error: 'Produto inválido.' });
    const product = await productService.getForUser(req.userId, id);
    if (!product) return res.status(404).json({ error: 'Produto não encontrado.' });
    return res.status(200).json({ product });
  },

  async create(req: AuthenticatedRequest, res: Response) {
    if (!req.userId) return res.status(401).json({ error: 'Usuário não autenticado.' });
    const parsed = productInputSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: 'Dados do produto inválidos.', details: parsed.error.flatten() });
    }
    try {
      return res.status(201).json({ product: await productService.create(req.userId, parsed.data) });
    } catch (error) {
      if (error instanceof Error && error.message === 'SELLER_REQUIRED') {
        return res.status(403).json({ error: 'Habilite sua conta de vendedor primeiro.' });
      }
      console.error('Erro ao criar produto:', error);
      return res.status(500).json({ error: 'Não foi possível criar o produto.' });
    }
  },

  async update(req: AuthenticatedRequest, res: Response) {
    if (!req.userId) return res.status(401).json({ error: 'Usuário não autenticado.' });
    const id = parseId(req.params.id);
    if (!id) return res.status(400).json({ error: 'Produto inválido.' });
    const parsed = productInputSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: 'Dados do produto inválidos.', details: parsed.error.flatten() });
    }
    try {
      return res.status(200).json({ product: await productService.update(req.userId, id, parsed.data) });
    } catch (error) {
      if (error instanceof Error && error.message === 'PRODUCT_NOT_FOUND') {
        return res.status(404).json({ error: 'Produto não encontrado.' });
      }
      console.error('Erro ao atualizar produto:', error);
      return res.status(500).json({ error: 'Não foi possível atualizar o produto.' });
    }
  },

  async remove(req: AuthenticatedRequest, res: Response) {
    if (!req.userId) return res.status(401).json({ error: 'Usuário não autenticado.' });
    const id = parseId(req.params.id);
    if (!id) return res.status(400).json({ error: 'Produto inválido.' });
    try {
      await productService.remove(req.userId, id);
      return res.status(204).send();
    } catch (error) {
      if (error instanceof Error && error.message === 'PRODUCT_HAS_ORDERS') {
        return res.status(409).json({
          error: 'Este produto já possui pedidos e não pode ser excluído. Pause o anúncio em vez disso.',
        });
      }
      if (error instanceof Error && error.message === 'PRODUCT_NOT_FOUND') {
        return res.status(404).json({ error: 'Produto não encontrado.' });
      }
      console.error('Erro ao excluir produto:', error);
      return res.status(500).json({ error: 'Não foi possível excluir o produto.' });
    }
  },
};
