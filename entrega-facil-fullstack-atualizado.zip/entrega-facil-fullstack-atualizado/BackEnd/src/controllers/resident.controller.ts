import type { Response } from 'express';

import type { AuthenticatedRequest } from '../middlewares/auth.middleware.js';
import { updateResidentAddressSchema } from '../schemas/resident.schema.js';
import { residentService } from '../services/resident.service.js';

export const residentController = {
  async validate(req: AuthenticatedRequest, res: Response) {
    try {
      if (!req.userId) return res.status(401).json({ error: 'Usuário não autenticado.' });

      const result = await residentService.validate(req.userId);

      // Moradia não encontrada é um resultado de negócio, não uma falha técnica.
      if (!result.validated) {
        return res.status(200).json({
          validated: false,
          block: result.block,
          apartment: result.apartment,
          message: 'Não foi possível confirmar este bloco e apartamento nos dados do condomínio.',
        });
      }

      return res.status(200).json({
        validated: true,
        block: result.block,
        apartment: result.apartment,
        message: result.alreadyValidated
          ? 'Morador já estava validado.'
          : 'Morador validado com sucesso.',
      });
    } catch (error) {
      console.error('Erro ao validar morador:', error);
      return res.status(500).json({ error: 'Não foi possível validar o morador.' });
    }
  },

  async updateAddress(req: AuthenticatedRequest, res: Response) {
    if (!req.userId) return res.status(401).json({ error: 'Usuário não autenticado.' });

    const parsed = updateResidentAddressSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({
        error: 'Dados de moradia inválidos.',
        details: parsed.error.flatten(),
      });
    }

    try {
      return res.status(200).json(
        await residentService.updateAddress(req.userId, parsed.data),
      );
    } catch (error) {
      if (error instanceof Error && error.message === 'CONDOMINIUM_NOT_FOUND') {
        return res.status(404).json({ error: 'Condomínio não encontrado.' });
      }
      if (error instanceof Error && error.message === 'USER_NOT_FOUND') {
        return res.status(404).json({ error: 'Usuário não encontrado.' });
      }
      console.error('Erro ao atualizar dados de moradia:', error);
      return res.status(500).json({ error: 'Não foi possível atualizar os dados de moradia.' });
    }
  },
};
