import type { PoolConnection, ResultSetHeader, RowDataPacket } from 'mysql2/promise';

import { db } from '../config/database.js';
import type { CreateOrderInput, RatingInput } from '../schemas/order.schema.js';
import type { ProductResponse } from './product.service.js';
import type { UserResponse } from './user.service.js';
import { userService } from './user.service.js';

type OrderStatus =
  | 'pending'
  | 'confirmed'
  | 'preparing'
  | 'ready'
  | 'delivering'
  | 'delivered'
  | 'cancelled';

interface OrderResponse {
  id: string;
  buyerId: string;
  sellerId: string;
  condominiumId: string;
  items: Array<{
    product: ProductResponse;
    qty: number;
    schedDate: string;
    schedTime: string;
  }>;
  total: number;
  status: OrderStatus;
  paymentMethod: 'cash';
  paymentStatus: 'pending' | 'approved';
  date: string;
  updatedAt: string;
  receiptConfirmedAt?: string;
  buyerRating?: number;
  sellerRating?: number;
  buyerComment?: string;
  sellerComment?: string;
}

interface OrderRow extends RowDataPacket {
  id: number;
  comprador_id: number;
  vendedor_id: number;
  condominio_id: number;
  total: string | number;
  status: OrderStatus;
  pagamento_status: 'pending' | 'approved';
  criado_em: Date | string;
  atualizado_em: Date | string;
  recebimento_confirmado_em: Date | string | null;
}

interface ItemRow extends RowDataPacket {
  quantidade: number;
  data_agendada: Date | string | null;
  hora_agendada: string | null;
  id: number;
  vendedor_id: number;
  condominio_id: number;
  nome: string;
  descricao: string;
  preco: string | number;
  custo: string | number | null;
  estoque: number;
  categoria: string;
  imagem_url: string | null;
  tipo: 'product' | 'service';
  disponivel: number;
  rating: string | number;
  total_ratings: number;
  duracao: string | null;
  hora_inicio: string | null;
  hora_fim: string | null;
  dias_disponiveis: string | number[] | null;
}

interface RatingRow extends RowDataPacket {
  papel_avaliador: 'buyer' | 'seller';
  nota: number;
  comentario: string | null;
}

interface PurchaseProductRow extends RowDataPacket {
  id: number;
  vendedor_id: number;
  condominio_id: number;
  preco: string | number;
  estoque: number;
  disponivel: number;
  tipo: 'product' | 'service';
  hora_inicio: string | null;
  hora_fim: string | null;
  dias_produto: string | number[] | null;
  hora_condominio_inicio: number;
  hora_condominio_fim: number;
  dias_condominio: string | number[];
}

const NEXT_STATUSES: Record<OrderStatus, OrderStatus[]> = {
  pending: ['confirmed', 'cancelled'],
  confirmed: ['preparing', 'cancelled'],
  preparing: ['ready'],
  ready: ['delivering'],
  delivering: ['delivered'],
  delivered: [],
  cancelled: [],
};

function parseDays(value: string | number[] | null): number[] {
  if (value == null) return [];
  if (Array.isArray(value)) return value.map(Number);
  try {
    const parsed = JSON.parse(value) as unknown;
    return Array.isArray(parsed) ? parsed.map(Number) : [];
  } catch {
    return [];
  }
}

function dateOnly(value: Date | string | null): string {
  if (!value) return '';
  if (value instanceof Date) return value.toISOString().slice(0, 10);
  return String(value).slice(0, 10);
}

function dateTime(value: Date | string | null): string | undefined {
  if (!value) return undefined;
  if (value instanceof Date) return value.toISOString();
  const raw = String(value);
  return raw.includes('T') ? raw : raw.replace(' ', 'T') + 'Z';
}

function timeOnly(value: string | null): string {
  return value ? value.slice(0, 5) : '';
}

function mapItemProduct(row: ItemRow): ProductResponse {
  const days = parseDays(row.dias_disponiveis);
  return {
    id: String(row.id),
    sellerId: String(row.vendedor_id),
    condominiumId: String(row.condominio_id),
    name: row.nome,
    description: row.descricao,
    price: Number(row.preco),
    ...(row.custo == null ? {} : { cost: Number(row.custo) }),
    stock: row.estoque,
    category: row.categoria,
    img: row.imagem_url ?? '',
    type: row.tipo,
    available: Boolean(row.disponivel),
    rating: Number(row.rating),
    totalRatings: row.total_ratings,
    ...(row.duracao ? { duration: row.duracao } : {}),
    ...(days.length ? { availableDays: days } : {}),
    ...(row.hora_inicio ? { availableStart: timeOnly(row.hora_inicio) } : {}),
    ...(row.hora_fim ? { availableEnd: timeOnly(row.hora_fim) } : {}),
  };
}

function validateServiceSchedule(product: PurchaseProductRow, schedDate = '', schedTime = '') {
  if (product.tipo !== 'service') return;
  if (!schedDate || !schedTime) throw new Error('INVALID_SCHEDULE');

  const date = new Date(`${schedDate}T12:00:00Z`);
  if (Number.isNaN(date.getTime())) throw new Error('INVALID_SCHEDULE');
  const weekday = date.getUTCDay();

  const condoDays = parseDays(product.dias_condominio);
  const productDays = parseDays(product.dias_produto);
  const allowedDays = productDays.length ? productDays : condoDays;
  if (!allowedDays.includes(weekday)) throw new Error('INVALID_SCHEDULE');

  const condoStart = `${String(product.hora_condominio_inicio).padStart(2, '0')}:00`;
  const condoEnd = `${String(product.hora_condominio_fim).padStart(2, '0')}:00`;
  const start = product.hora_inicio ? timeOnly(product.hora_inicio) : condoStart;
  const end = product.hora_fim ? timeOnly(product.hora_fim) : condoEnd;

  if (schedTime < start || schedTime > end || schedTime < condoStart || schedTime > condoEnd) {
    throw new Error('INVALID_SCHEDULE');
  }
}

async function getOrderById(orderId: number): Promise<OrderResponse | null> {
  const [orders] = await db.query<OrderRow[]>(
    `SELECT * FROM pedidos WHERE id = ? LIMIT 1`,
    [orderId],
  );
  const order = orders[0];
  if (!order) return null;

  const [items] = await db.query<ItemRow[]>(
    `
      SELECT
        i.quantidade,
        i.data_agendada,
        i.hora_agendada,
        p.id,
        p.vendedor_id,
        p.condominio_id,
        p.nome,
        p.descricao,
        p.preco,
        p.custo,
        p.estoque,
        p.categoria,
        p.imagem_url,
        p.tipo,
        p.disponivel,
        p.rating,
        p.total_ratings,
        p.duracao,
        p.hora_inicio,
        p.hora_fim,
        (
          SELECT JSON_ARRAYAGG(pd.dia_semana)
          FROM produto_dias_disponiveis pd
          WHERE pd.produto_id = p.id
        ) AS dias_disponiveis
      FROM itens_pedido i
      JOIN produtos p ON p.id = i.produto_id
      WHERE i.pedido_id = ?
      ORDER BY i.id
    `,
    [orderId],
  );

  const [ratings] = await db.query<RatingRow[]>(
    `SELECT papel_avaliador, nota, comentario FROM avaliacoes WHERE pedido_id = ?`,
    [orderId],
  );
  const buyerRating = ratings.find((r) => r.papel_avaliador === 'buyer');
  const sellerRating = ratings.find((r) => r.papel_avaliador === 'seller');
  const receipt = dateTime(order.recebimento_confirmado_em);

  return {
    id: String(order.id),
    buyerId: String(order.comprador_id),
    sellerId: String(order.vendedor_id),
    condominiumId: String(order.condominio_id),
    items: items.map((item) => ({
      product: mapItemProduct(item),
      qty: item.quantidade,
      schedDate: dateOnly(item.data_agendada),
      schedTime: timeOnly(item.hora_agendada),
    })),
    total: Number(order.total),
    status: order.status,
    paymentMethod: 'cash',
    paymentStatus: order.pagamento_status,
    date: dateOnly(order.criado_em),
    updatedAt: dateOnly(order.atualizado_em),
    ...(receipt ? { receiptConfirmedAt: receipt } : {}),
    ...(buyerRating ? { buyerRating: buyerRating.nota, buyerComment: buyerRating.comentario ?? '' } : {}),
    ...(sellerRating ? { sellerRating: sellerRating.nota, sellerComment: sellerRating.comentario ?? '' } : {}),
  };
}

async function getOrderRowForUpdate(connection: PoolConnection, orderId: number) {
  const [rows] = await connection.query<OrderRow[]>(
    `SELECT * FROM pedidos WHERE id = ? FOR UPDATE`,
    [orderId],
  );
  return rows[0] ?? null;
}

export const orderService = {
  async listForUser(userId: number): Promise<{ orders: OrderResponse[]; users: UserResponse[] }> {
    const [rows] = await db.query<Array<RowDataPacket & { id: number; comprador_id: number; vendedor_id: number }>>(
      `
        SELECT id, comprador_id, vendedor_id
        FROM pedidos
        WHERE comprador_id = ? OR vendedor_id = ?
        ORDER BY criado_em DESC
      `,
      [userId, userId],
    );

    const orders = (
      await Promise.all(rows.map((row) => getOrderById(row.id)))
    ).filter((order): order is OrderResponse => Boolean(order));

    const userIds = [...new Set(rows.flatMap((row) => [row.comprador_id, row.vendedor_id]))];
    const users = (
      await Promise.all(userIds.map((id) => userService.findById(id, true)))
    ).filter((user): user is UserResponse => Boolean(user));

    return { orders, users };
  },

  async create(userId: number, data: CreateOrderInput): Promise<OrderResponse> {
    const buyer = await userService.findById(userId);
    if (!buyer) throw new Error('USER_NOT_FOUND');
    if (!buyer.validated) throw new Error('USER_NOT_VALIDATED');

    const connection = await db.getConnection();
    let orderId = 0;
    try {
      await connection.beginTransaction();

      let sellerId: number | null = null;
      let total = 0;
      const checkedItems: Array<{
        product: PurchaseProductRow;
        qty: number;
        schedDate: string;
        schedTime: string;
      }> = [];

      for (const item of data.items) {
        const [products] = await connection.query<PurchaseProductRow[]>(
          `
            SELECT
              p.id,
              p.vendedor_id,
              p.condominio_id,
              p.preco,
              p.estoque,
              p.disponivel,
              p.tipo,
              p.hora_inicio,
              p.hora_fim,
              (
                SELECT JSON_ARRAYAGG(pd.dia_semana)
                FROM produto_dias_disponiveis pd
                WHERE pd.produto_id = p.id
              ) AS dias_produto,
              c.hora_inicio AS hora_condominio_inicio,
              c.hora_fim AS hora_condominio_fim,
              c.dias_permitidos AS dias_condominio
            FROM produtos p
            JOIN condominios c ON c.id = p.condominio_id
            WHERE p.id = ?
            FOR UPDATE
          `,
          [item.productId],
        );

        const product = products[0];
        if (!product || !Boolean(product.disponivel)) throw new Error('PRODUCT_UNAVAILABLE');
        if (product.condominio_id !== Number(buyer.condominiumId)) throw new Error('WRONG_CONDOMINIUM');
        if (product.estoque < item.qty) throw new Error('INSUFFICIENT_STOCK');

        if (sellerId === null) sellerId = product.vendedor_id;
        if (sellerId !== product.vendedor_id) throw new Error('MULTIPLE_SELLERS');
        if (sellerId === userId) throw new Error('SELF_PURCHASE');

        validateServiceSchedule(product, item.schedDate ?? '', item.schedTime ?? '');
        total += Number(product.preco) * item.qty;
        checkedItems.push({
          product,
          qty: item.qty,
          schedDate: item.schedDate ?? '',
          schedTime: item.schedTime ?? '',
        });
      }

      if (sellerId === null) throw new Error('EMPTY_ORDER');

      const [orderResult] = await connection.execute<ResultSetHeader>(
        `
          INSERT INTO pedidos (
            comprador_id, vendedor_id, condominio_id, total, status, pagamento_status
          )
          VALUES (?, ?, ?, ?, 'pending', 'pending')
        `,
        [userId, sellerId, Number(buyer.condominiumId), total],
      );
      orderId = orderResult.insertId;

      for (const item of checkedItems) {
        await connection.execute(
          `
            INSERT INTO itens_pedido (
              pedido_id, produto_id, quantidade, preco_unitario, data_agendada, hora_agendada
            )
            VALUES (?, ?, ?, ?, ?, ?)
          `,
          [
            orderId,
            item.product.id,
            item.qty,
            Number(item.product.preco),
            item.schedDate || null,
            item.schedTime || null,
          ],
        );
        await connection.execute(
          `UPDATE produtos SET estoque = estoque - ? WHERE id = ?`,
          [item.qty, item.product.id],
        );
      }

      await connection.commit();
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }

    const order = await getOrderById(orderId);
    if (!order) throw new Error('ORDER_NOT_FOUND_AFTER_INSERT');
    return order;
  },

  async updateStatus(userId: number, orderId: number, status: OrderStatus): Promise<OrderResponse> {
    const connection = await db.getConnection();
    try {
      await connection.beginTransaction();
      const order = await getOrderRowForUpdate(connection, orderId);
      if (!order) throw new Error('ORDER_NOT_FOUND');
      if (order.vendedor_id !== userId) throw new Error('FORBIDDEN');
      if (!NEXT_STATUSES[order.status].includes(status)) throw new Error('INVALID_STATUS_TRANSITION');

      if (status === 'cancelled') {
        const [items] = await connection.query<Array<RowDataPacket & { produto_id: number; quantidade: number }>>(
          `SELECT produto_id, quantidade FROM itens_pedido WHERE pedido_id = ?`,
          [orderId],
        );
        for (const item of items) {
          await connection.execute(
            `UPDATE produtos SET estoque = estoque + ? WHERE id = ?`,
            [item.quantidade, item.produto_id],
          );
        }
      }

      await connection.execute(
        `
          UPDATE pedidos
          SET status = ?, pagamento_status = CASE WHEN ? = 'delivered' THEN 'approved' ELSE pagamento_status END
          WHERE id = ?
        `,
        [status, status, orderId],
      );
      await connection.commit();
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }

    const order = await getOrderById(orderId);
    if (!order) throw new Error('ORDER_NOT_FOUND');
    return order;
  },

  async confirmReceipt(userId: number, orderId: number): Promise<OrderResponse> {
    const [result] = await db.execute<ResultSetHeader>(
      `
        UPDATE pedidos
        SET recebimento_confirmado_em = CURRENT_TIMESTAMP
        WHERE id = ?
          AND comprador_id = ?
          AND status = 'delivered'
          AND recebimento_confirmado_em IS NULL
      `,
      [orderId, userId],
    );
    if (result.affectedRows === 0) throw new Error('RECEIPT_NOT_ALLOWED');
    const order = await getOrderById(orderId);
    if (!order) throw new Error('ORDER_NOT_FOUND');
    return order;
  },

  async rate(userId: number, orderId: number, data: RatingInput): Promise<OrderResponse> {
    const connection = await db.getConnection();
    try {
      await connection.beginTransaction();
      const order = await getOrderRowForUpdate(connection, orderId);
      if (!order) throw new Error('ORDER_NOT_FOUND');
      if (order.status !== 'delivered') throw new Error('RATING_NOT_ALLOWED');

      const isBuyer = order.comprador_id === userId;
      const isSeller = order.vendedor_id === userId;
      if (!isBuyer && !isSeller) throw new Error('FORBIDDEN');
      if ((data.role === 'buyer' && !isBuyer) || (data.role === 'seller' && !isSeller)) {
        throw new Error('FORBIDDEN');
      }
      if (data.role === 'buyer' && !order.recebimento_confirmado_em) {
        throw new Error('RATING_NOT_ALLOWED');
      }

      const evaluatedId = data.role === 'buyer' ? order.vendedor_id : order.comprador_id;
      try {
        await connection.execute(
          `
            INSERT INTO avaliacoes (
              pedido_id, avaliador_id, avaliado_id, papel_avaliador, nota, comentario
            ) VALUES (?, ?, ?, ?, ?, ?)
          `,
          [orderId, userId, evaluatedId, data.role, data.rating, data.comment || null],
        );
      } catch (error) {
        if (
          error instanceof Error &&
          'code' in error &&
          (error as Error & { code?: string }).code === 'ER_DUP_ENTRY'
        ) {
          throw new Error('RATING_ALREADY_EXISTS');
        }
        throw error;
      }

      await connection.execute(
        `
          UPDATE usuarios
          SET
            rating = ROUND(((rating * total_ratings) + ?) / (total_ratings + 1), 2),
            total_ratings = total_ratings + 1
          WHERE id = ?
        `,
        [data.rating, evaluatedId],
      );

      if (data.role === 'buyer') {
        const [items] = await connection.query<Array<RowDataPacket & { produto_id: number }>>(
          `SELECT DISTINCT produto_id FROM itens_pedido WHERE pedido_id = ?`,
          [orderId],
        );
        for (const item of items) {
          await connection.execute(
            `
              UPDATE produtos
              SET
                rating = ROUND(((rating * total_ratings) + ?) / (total_ratings + 1), 2),
                total_ratings = total_ratings + 1
              WHERE id = ?
            `,
            [data.rating, item.produto_id],
          );
        }
      }

      await connection.commit();
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }

    const order = await getOrderById(orderId);
    if (!order) throw new Error('ORDER_NOT_FOUND');
    return order;
  },
};
