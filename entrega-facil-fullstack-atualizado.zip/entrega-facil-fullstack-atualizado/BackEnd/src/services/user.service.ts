import type { RowDataPacket } from 'mysql2';
import { db } from '../config/database.js';

export interface SellerProfileResponse {
  businessName: string;
  category: string;
  description: string;
  phone: string;
  hours: string;
}

export interface UserResponse {
  id: string;
  name: string;
  email: string;
  cpf: string;
  condominiumId: string;
  block: string;
  apartment: string;
  role: 'buyer' | 'both';
  sellerProfile?: SellerProfileResponse;
  rating: number;
  totalRatings: number;
  validated: boolean;
}

interface UserRow extends RowDataPacket {
  id: number;
  nome: string;
  email: string;
  cpf: string;
  senha_hash: string;
  condominio_id: number;
  bloco: string;
  apartamento: string;
  papel: 'buyer' | 'both';
  validado: number;
  ativo: number;
  rating: string | number;
  total_ratings: number;
  nome_negocio: string | null;
  vendedor_categoria: string | null;
  vendedor_descricao: string | null;
  vendedor_telefone: string | null;
  horario_atendimento: string | null;
}

const USER_SELECT = `
  SELECT
    u.id,
    u.nome,
    u.email,
    u.cpf,
    u.senha_hash,
    u.condominio_id,
    u.bloco,
    u.apartamento,
    u.papel,
    u.validado,
    u.ativo,
    u.rating,
    u.total_ratings,
    pv.nome_negocio,
    pv.categoria AS vendedor_categoria,
    pv.descricao AS vendedor_descricao,
    pv.telefone AS vendedor_telefone,
    pv.horario_atendimento
  FROM usuarios u
  LEFT JOIN perfis_vendedor pv
    ON pv.usuario_id = u.id
`;

function mapUser(row: UserRow): UserResponse {
  const sellerProfile =
    row.papel === 'both' && row.nome_negocio
      ? {
          businessName: row.nome_negocio,
          category: row.vendedor_categoria ?? 'Outros',
          description: row.vendedor_descricao ?? '',
          phone: row.vendedor_telefone ?? '',
          hours: row.horario_atendimento ?? '',
        }
      : undefined;

  return {
    id: String(row.id),
    name: row.nome,
    email: row.email,
    cpf: row.cpf,
    condominiumId: String(row.condominio_id),
    block: row.bloco,
    apartment: row.apartamento,
    role: row.papel,
    ...(sellerProfile ? { sellerProfile } : {}),
    rating: Number(row.rating),
    totalRatings: row.total_ratings,
    validated: Boolean(row.validado),
  };
}

export const userService = {
  async findById(userId: number, includeInactive = false): Promise<UserResponse | null> {
    const [rows] = await db.query<UserRow[]>(
      `${USER_SELECT}
       WHERE u.id = ? ${includeInactive ? '' : 'AND u.ativo = TRUE'}
       LIMIT 1`,
      [userId],
    );

    return rows[0] ? mapUser(rows[0]) : null;
  },

  async findAuthRowByEmail(email: string): Promise<UserRow | null> {
    const [rows] = await db.query<UserRow[]>(
      `${USER_SELECT}
       WHERE u.email = ?
         AND u.ativo = TRUE
       LIMIT 1`,
      [email.trim().toLowerCase()],
    );

    return rows[0] ?? null;
  },

  async findAuthRowById(userId: number): Promise<UserRow | null> {
    const [rows] = await db.query<UserRow[]>(
      `${USER_SELECT}
       WHERE u.id = ?
         AND u.ativo = TRUE
       LIMIT 1`,
      [userId],
    );

    return rows[0] ?? null;
  },

  mapAuthRow(row: UserRow): UserResponse {
    return mapUser(row);
  },
};
