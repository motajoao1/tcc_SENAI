import type { ResultSetHeader, RowDataPacket } from 'mysql2';

import { db } from '../config/database.js';
import type { ProductInput } from '../schemas/product.schema.js';
import type { UserResponse } from './user.service.js';
import { userService } from './user.service.js';

export interface ProductResponse {
  id: string;
  sellerId: string;
  condominiumId: string;
  name: string;
  description: string;
  price: number;
  cost?: number;
  stock: number;
  category: string;
  img: string;
  type: 'product' | 'service';
  available: boolean;
  rating: number;
  totalRatings: number;
  duration?: string;
  availableDays?: number[];
  availableStart?: string;
  availableEnd?: string;
}

interface ProductRow extends RowDataPacket {
  id: number;
  vendedor_id: number;
  condominio_id: number;
  nome: string;
  descricao: string;
  preco: string | number;
  custo: string | number | null;
  estoque: number;
  categoria: string;
  imagem_url: string | null;
  tipo: 'product' | 'service';
  disponivel: number;
  rating: string | number;
  total_ratings: number;
  duracao: string | null;
  hora_inicio: string | null;
  hora_fim: string | null;
  dias_disponiveis: string | number[] | null;
}

const PRODUCT_SELECT = `
  SELECT
    p.id,
    p.vendedor_id,
    p.condominio_id,
    p.nome,
    p.descricao,
    p.preco,
    p.custo,
    p.estoque,
    p.categoria,
    p.imagem_url,
    p.tipo,
    p.disponivel,
    p.rating,
    p.total_ratings,
    p.duracao,
    p.hora_inicio,
    p.hora_fim,
    (
      SELECT JSON_ARRAYAGG(pd.dia_semana)
      FROM produto_dias_disponiveis pd
      WHERE pd.produto_id = p.id
    ) AS dias_disponiveis
  FROM produtos p
`;

function parseDays(value: ProductRow['dias_disponiveis']): number[] | undefined {
  if (value == null) return undefined;
  if (Array.isArray(value)) return value.map(Number);
  try {
    const parsed = JSON.parse(value) as unknown;
    return Array.isArray(parsed) ? parsed.map(Number) : undefined;
  } catch {
    return undefined;
  }
}

function normalizeTime(value: string | null): string | undefined {
  if (!value) return undefined;
  return value.slice(0, 5);
}

function mapProduct(row: ProductRow): ProductResponse {
  const days = parseDays(row.dias_disponiveis);
  const cost = row.custo == null ? undefined : Number(row.custo);
  const duration = row.duracao ?? undefined;
  const start = normalizeTime(row.hora_inicio);
  const end = normalizeTime(row.hora_fim);

  return {
    id: String(row.id),
    sellerId: String(row.vendedor_id),
    condominiumId: String(row.condominio_id),
    name: row.nome,
    description: row.descricao,
    price: Number(row.preco),
    ...(cost !== undefined ? { cost } : {}),
    stock: row.estoque,
    category: row.categoria,
    img: row.imagem_url ?? '',
    type: row.tipo,
    available: Boolean(row.disponivel),
    rating: Number(row.rating),
    totalRatings: row.total_ratings,
    ...(duration ? { duration } : {}),
    ...(days ? { availableDays: days } : {}),
    ...(start ? { availableStart: start } : {}),
    ...(end ? { availableEnd: end } : {}),
  };
}

async function replaceAvailableDays(
  connection: Awaited<ReturnType<typeof db.getConnection>>,
  productId: number,
  days: number[] | undefined,
) {
  await connection.execute(`DELETE FROM produto_dias_disponiveis WHERE produto_id = ?`, [productId]);
  const uniqueDays = [...new Set(days ?? [])].sort((a, b) => a - b);
  for (const day of uniqueDays) {
    await connection.execute(
      `INSERT INTO produto_dias_disponiveis (produto_id, dia_semana) VALUES (?, ?)`,
      [productId, day],
    );
  }
}

export const productService = {
  async listForUser(userId: number): Promise<{ products: ProductResponse[]; users: UserResponse[] }> {
    const currentUser = await userService.findById(userId);
    if (!currentUser) throw new Error('USER_NOT_FOUND');

    const [rows] = await db.query<ProductRow[]>(
      `${PRODUCT_SELECT}
       WHERE p.condominio_id = ?
         AND (p.disponivel = TRUE OR p.vendedor_id = ?)
       ORDER BY p.criado_em DESC`,
      [Number(currentUser.condominiumId), userId],
    );

    const products = rows.map(mapProduct);
    const sellerIds = [...new Set(rows.map((row) => row.vendedor_id))];
    const users = (
      await Promise.all(sellerIds.map((sellerId) => userService.findById(sellerId)))
    ).filter((user): user is UserResponse => Boolean(user));

    return { products, users };
  },

  async getForUser(userId: number, productId: number): Promise<ProductResponse | null> {
    const currentUser = await userService.findById(userId);
    if (!currentUser) throw new Error('USER_NOT_FOUND');

    const [rows] = await db.query<ProductRow[]>(
      `${PRODUCT_SELECT}
       WHERE p.id = ?
         AND p.condominio_id = ?
         AND (p.disponivel = TRUE OR p.vendedor_id = ?)
       LIMIT 1`,
      [productId, Number(currentUser.condominiumId), userId],
    );

    return rows[0] ? mapProduct(rows[0]) : null;
  },

  async create(userId: number, data: ProductInput): Promise<ProductResponse> {
    const currentUser = await userService.findById(userId);
    if (!currentUser) throw new Error('USER_NOT_FOUND');
    if (!currentUser.validated) throw new Error('USER_NOT_VALIDATED');
    if (currentUser.role !== 'both') throw new Error('SELLER_REQUIRED');

    const connection = await db.getConnection();
    let productId = 0;
    try {
      await connection.beginTransaction();
      const [result] = await connection.execute<ResultSetHeader>(
        `
          INSERT INTO produtos (
            vendedor_id, condominio_id, nome, descricao, preco, custo, estoque,
            categoria, imagem_url, tipo, disponivel, rating, total_ratings,
            duracao, hora_inicio, hora_fim
          )
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, ?, ?, ?)
        `,
        [
          userId,
          Number(currentUser.condominiumId),
          data.name.trim(),
          data.description.trim(),
          data.price,
          data.cost ?? null,
          data.stock,
          data.category,
          data.img.trim(),
          data.type,
          data.available,
          data.duration?.trim() || null,
          data.availableStart || null,
          data.availableEnd || null,
        ],
      );
      productId = result.insertId;
      await replaceAvailableDays(connection, productId, data.availableDays);
      await connection.commit();
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }

    const product = await this.getForUser(userId, productId);
    if (!product) throw new Error('PRODUCT_NOT_FOUND_AFTER_INSERT');
    return product;
  },

  async update(userId: number, productId: number, data: ProductInput): Promise<ProductResponse> {
    const connection = await db.getConnection();
    try {
      await connection.beginTransaction();
      const [result] = await connection.execute<ResultSetHeader>(
        `
          UPDATE produtos
          SET
            nome = ?, descricao = ?, preco = ?, custo = ?, estoque = ?, categoria = ?,
            imagem_url = ?, tipo = ?, disponivel = ?, duracao = ?, hora_inicio = ?, hora_fim = ?
          WHERE id = ? AND vendedor_id = ?
        `,
        [
          data.name.trim(),
          data.description.trim(),
          data.price,
          data.cost ?? null,
          data.stock,
          data.category,
          data.img.trim(),
          data.type,
          data.available,
          data.duration?.trim() || null,
          data.availableStart || null,
          data.availableEnd || null,
          productId,
          userId,
        ],
      );
      if (result.affectedRows === 0) throw new Error('PRODUCT_NOT_FOUND');
      await replaceAvailableDays(connection, productId, data.availableDays);
      await connection.commit();
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }

    const product = await this.getForUser(userId, productId);
    if (!product) throw new Error('PRODUCT_NOT_FOUND');
    return product;
  },

  async remove(userId: number, productId: number) {
    try {
      const [result] = await db.execute<ResultSetHeader>(
        `DELETE FROM produtos WHERE id = ? AND vendedor_id = ?`,
        [productId, userId],
      );
      if (result.affectedRows === 0) throw new Error('PRODUCT_NOT_FOUND');
    } catch (error) {
      if (
        error instanceof Error &&
        'code' in error &&
        (error as Error & { code?: string }).code === 'ER_ROW_IS_REFERENCED_2'
      ) {
        throw new Error('PRODUCT_HAS_ORDERS');
      }
      throw error;
    }
  },
};
