import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import type { ResultSetHeader, RowDataPacket } from 'mysql2';

import { db } from '../config/database.js';
import type {
  LoginInput,
  RegisterInput,
  UpdateCurrentUserInput,
} from '../schemas/auth.schema.js';
import { userService } from './user.service.js';

function jwtSecret(): string {
  const secret = process.env.JWT_SECRET;
  if (!secret) throw new Error('JWT_SECRET não configurado.');
  return secret;
}

function createToken(id: number) {
  return jwt.sign({ sub: String(id) }, jwtSecret(), { expiresIn: '8h' });
}

export const authService = {
  async register(data: RegisterInput) {
    // Falha antes do INSERT caso o servidor esteja sem segredo JWT.
    jwtSecret();

    const [existing] = await db.query<Array<RowDataPacket & { id: number }>>(
      `SELECT id FROM usuarios WHERE email = ? OR cpf = ? LIMIT 1`,
      [data.email.trim().toLowerCase(), data.cpf.trim()],
    );

    if (existing.length > 0) {
      throw new Error('EMAIL_OR_CPF_EXISTS');
    }

    const passwordHash = await bcrypt.hash(data.password, 12);
    const [result] = await db.execute<ResultSetHeader>(
      `
        INSERT INTO usuarios (
          nome, email, cpf, senha_hash, condominio_id,
          bloco, apartamento, papel, validado, ativo
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, 'buyer', FALSE, TRUE)
      `,
      [
        data.name.trim(),
        data.email.trim().toLowerCase(),
        data.cpf.trim(),
        passwordHash,
        data.condominiumId,
        data.block.trim(),
        data.apartment.trim(),
      ],
    );

    const user = await userService.findById(result.insertId);
    if (!user) throw new Error('USER_NOT_FOUND_AFTER_INSERT');

    return { user, token: createToken(result.insertId) };
  },

  async login(data: LoginInput) {
    const row = await userService.findAuthRowByEmail(data.email);
    if (!row) return null;

    const validPassword = await bcrypt.compare(data.password, row.senha_hash);
    if (!validPassword) return null;

    return {
      user: userService.mapAuthRow(row),
      token: createToken(row.id),
    };
  },

  async me(userId: number) {
    return userService.findById(userId);
  },

  async updateMe(userId: number, data: UpdateCurrentUserInput) {
    const connection = await db.getConnection();
    try {
      await connection.beginTransaction();

      const [result] = await connection.execute<ResultSetHeader>(
        `UPDATE usuarios SET nome = ? WHERE id = ? AND ativo = TRUE`,
        [data.name.trim(), userId],
      );

      if (result.affectedRows === 0) throw new Error('USER_NOT_FOUND');

      if (data.phone !== undefined) {
        await connection.execute(
          `UPDATE perfis_vendedor SET telefone = ? WHERE usuario_id = ?`,
          [data.phone.trim(), userId],
        );
      }

      await connection.commit();
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }

    const user = await userService.findById(userId);
    if (!user) throw new Error('USER_NOT_FOUND');
    return user;
  },

  async deleteMe(userId: number) {
    const connection = await db.getConnection();
    try {
      await connection.beginTransaction();

      await connection.execute(
        `UPDATE produtos SET disponivel = FALSE WHERE vendedor_id = ?`,
        [userId],
      );
      await connection.execute(`DELETE FROM perfis_vendedor WHERE usuario_id = ?`, [userId]);

      const [result] = await connection.execute<ResultSetHeader>(
        `
          UPDATE usuarios
          SET
            nome = 'Usuário removido',
            email = CONCAT('removed+', id, '@entregafacil.local'),
            cpf = CONCAT('R', LPAD(id, 11, '0')),
            bloco = '—',
            apartamento = '—',
            papel = 'buyer',
            validado = FALSE,
            ativo = FALSE
          WHERE id = ? AND ativo = TRUE
        `,
        [userId],
      );

      if (result.affectedRows === 0) throw new Error('USER_NOT_FOUND');
      await connection.commit();
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }
  },
};
