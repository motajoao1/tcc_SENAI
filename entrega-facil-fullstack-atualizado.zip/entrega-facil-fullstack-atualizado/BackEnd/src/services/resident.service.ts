import type { ResultSetHeader, RowDataPacket } from 'mysql2';

import { db } from '../config/database.js';
import type { UpdateResidentAddressInput } from '../schemas/resident.schema.js';

interface UserAddressRow extends RowDataPacket {
  id: number;
  condominio_id: number;
  bloco: string;
  apartamento: string;
  validado: number;
}

interface UnitRow extends RowDataPacket {
  id: number;
  bloco: string;
  apartamento: string;
}

function normalizeBlock(value: string): string {
  return value
    .trim()
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/\s+/g, '')
    .replace(/^torre/, '')
    .replace(/^bloco/, '');
}

export const residentService = {
  async updateAddress(userId: number, data: UpdateResidentAddressInput) {
    const [condominiums] = await db.query<RowDataPacket[]>(
      `SELECT id FROM condominios WHERE id = ? LIMIT 1`,
      [data.condominiumId],
    );

    if (condominiums.length === 0) throw new Error('CONDOMINIUM_NOT_FOUND');

    const [result] = await db.execute<ResultSetHeader>(
      `
        UPDATE usuarios
        SET condominio_id = ?, bloco = ?, apartamento = ?, validado = FALSE
        WHERE id = ? AND ativo = TRUE
      `,
      [data.condominiumId, data.block.trim(), data.apartment.trim(), userId],
    );

    if (result.affectedRows === 0) throw new Error('USER_NOT_FOUND');

    return {
      condominiumId: String(data.condominiumId),
      block: data.block.trim(),
      apartment: data.apartment.trim(),
      validated: false,
    };
  },

  async validate(userId: number) {
    const [users] = await db.query<UserAddressRow[]>(
      `
        SELECT id, condominio_id, bloco, apartamento, validado
        FROM usuarios
        WHERE id = ? AND ativo = TRUE
        LIMIT 1
      `,
      [userId],
    );

    const user = users[0];
    if (!user) throw new Error('USER_NOT_FOUND');

    if (Boolean(user.validado)) {
      return {
        validated: true,
        alreadyValidated: true,
        block: user.bloco,
        apartment: user.apartamento,
      };
    }

    const [units] = await db.query<UnitRow[]>(
      `
        SELECT id, bloco, apartamento
        FROM unidades_condominio
        WHERE condominio_id = ?
          AND LOWER(TRIM(apartamento)) = LOWER(TRIM(?))
          AND ativo = TRUE
      `,
      [user.condominio_id, user.apartamento],
    );

    const normalizedUserBlock = normalizeBlock(user.bloco);
    const matchedUnit = units.find(
      (unit) => normalizeBlock(unit.bloco) === normalizedUserBlock,
    );

    if (!matchedUnit) {
      return {
        validated: false,
        alreadyValidated: false,
        block: user.bloco,
        apartment: user.apartamento,
      };
    }

    await db.execute<ResultSetHeader>(
      `
        UPDATE usuarios
        SET validado = TRUE, bloco = ?, apartamento = ?
        WHERE id = ?
      `,
      [matchedUnit.bloco, matchedUnit.apartamento, userId],
    );

    return {
      validated: true,
      alreadyValidated: false,
      block: matchedUnit.bloco,
      apartment: matchedUnit.apartamento,
    };
  },
};
