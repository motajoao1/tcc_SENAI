import type { ResultSetHeader } from 'mysql2';

import { db } from '../config/database.js';
import type { SellerProfileInput } from '../schemas/seller.schema.js';
import { userService } from './user.service.js';

export const sellerService = {
  async upsertProfile(userId: number, data: SellerProfileInput) {
    const currentUser = await userService.findById(userId);
    if (!currentUser) throw new Error('USER_NOT_FOUND');
    if (!currentUser.validated) throw new Error('USER_NOT_VALIDATED');

    const connection = await db.getConnection();
    try {
      await connection.beginTransaction();

      await connection.execute<ResultSetHeader>(
        `
          INSERT INTO perfis_vendedor (
            usuario_id, nome_negocio, categoria, descricao, telefone, horario_atendimento
          )
          VALUES (?, ?, ?, ?, ?, ?)
          ON DUPLICATE KEY UPDATE
            nome_negocio = VALUES(nome_negocio),
            categoria = VALUES(categoria),
            descricao = VALUES(descricao),
            telefone = VALUES(telefone),
            horario_atendimento = VALUES(horario_atendimento)
        `,
        [
          userId,
          data.businessName.trim(),
          data.category,
          data.description.trim(),
          data.phone.trim(),
          data.hours.trim(),
        ],
      );

      await connection.execute(
        `UPDATE usuarios SET papel = 'both' WHERE id = ? AND ativo = TRUE`,
        [userId],
      );

      await connection.commit();
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }

    const user = await userService.findById(userId);
    if (!user) throw new Error('USER_NOT_FOUND');
    return user;
  },
};
