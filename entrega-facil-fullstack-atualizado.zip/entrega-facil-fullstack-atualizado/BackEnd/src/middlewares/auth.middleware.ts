import type {
  NextFunction,
  Request,
  Response,
} from 'express';

import jwt from 'jsonwebtoken';

export interface AuthenticatedRequest extends Request {
  userId?: number;
}

interface JwtPayload {
  sub: string;
}

export function authMiddleware(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction,
) {
  const authorization = req.headers.authorization;

  if (!authorization?.startsWith('Bearer ')) {
    return res.status(401).json({
      error: 'Token de autenticação não informado.',
    });
  }

  const token = authorization.substring(7);

  const secret = process.env.JWT_SECRET;

  if (!secret) {
    console.error('JWT_SECRET não configurado.');

    return res.status(500).json({
      error: 'Erro de configuração do servidor.',
    });
  }

  try {
    const decoded = jwt.verify(
      token,
      secret,
    ) as JwtPayload;

    const userId = Number(decoded.sub);

    if (!Number.isInteger(userId) || userId <= 0) {
      return res.status(401).json({
        error: 'Token inválido.',
      });
    }

    req.userId = userId;

    return next();
  } catch {
    return res.status(401).json({
      error: 'Token inválido ou expirado.',
    });
  }
}