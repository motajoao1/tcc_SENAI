import { z } from 'zod';

const categories = [
  'Alimentos',
  'Serviços',
  'Roupas',
  'Beleza',
  'Artesanato',
  'Outros',
] as const;

export const sellerProfileSchema = z.object({
  businessName: z.string().trim().min(3).max(150),
  category: z.enum(categories),
  description: z.string().trim().min(15).max(2000),
  phone: z.string().trim().min(10).max(30),
  hours: z.string().trim().min(5).max(150),
});

export type SellerProfileInput = z.infer<typeof sellerProfileSchema>;
