import { z } from 'zod';

export const updateResidentAddressSchema = z.object({
  condominiumId: z.coerce
    .number()
    .int()
    .positive(),

  block: z
    .string()
    .trim()
    .min(1, 'Informe o bloco ou torre')
    .max(50),

  apartment: z
    .string()
    .trim()
    .min(1, 'Informe o apartamento')
    .max(30),
});

export type UpdateResidentAddressInput =
  z.infer<typeof updateResidentAddressSchema>;  