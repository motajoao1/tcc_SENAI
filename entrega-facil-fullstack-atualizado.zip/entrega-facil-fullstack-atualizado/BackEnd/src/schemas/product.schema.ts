import { z } from 'zod';

const categories = [
  'Alimentos',
  'Serviços',
  'Roupas',
  'Beleza',
  'Artesanato',
  'Outros',
] as const;

const timePattern = /^([01]\d|2[0-3]):[0-5]\d$/;

export const productInputSchema = z.object({
  name: z.string().trim().min(3).max(150),
  description: z.string().trim().min(5).max(5000),
  price: z.coerce.number().positive(),
  cost: z.coerce.number().nonnegative().optional().nullable(),
  stock: z.coerce.number().int().nonnegative(),
  category: z.enum(categories),
  img: z.string().trim().min(1).max(500),
  type: z.enum(['product', 'service']),
  available: z.boolean().default(true),
  duration: z.string().trim().max(50).optional().nullable(),
  availableDays: z.array(z.number().int().min(0).max(6)).optional(),
  availableStart: z.string().regex(timePattern).optional().nullable(),
  availableEnd: z.string().regex(timePattern).optional().nullable(),
});

export type ProductInput = z.infer<typeof productInputSchema>;
