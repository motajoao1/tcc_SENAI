import { z } from 'zod';

export const registerSchema = z.object({
  name: z.string().trim().min(3),
  email: z.string().trim().email(),
  password: z.string().min(6),
  cpf: z.string().trim().min(11).max(14),
  condominiumId: z.coerce.number().int().positive(),
  block: z.string().trim().min(1).max(50),
  apartment: z.string().trim().min(1).max(30),
});

export const loginSchema = z.object({
  email: z.string().trim().email(),
  password: z.string().min(6),
});

export const updateCurrentUserSchema = z.object({
  name: z.string().trim().min(3).max(150),
  phone: z.string().trim().max(30).optional(),
});

export type RegisterInput = z.infer<typeof registerSchema>;
export type LoginInput = z.infer<typeof loginSchema>;
export type UpdateCurrentUserInput = z.infer<typeof updateCurrentUserSchema>;
