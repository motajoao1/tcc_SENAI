import { z } from 'zod';

const datePattern = /^\d{4}-\d{2}-\d{2}$/;
const timePattern = /^([01]\d|2[0-3]):[0-5]\d$/;

export const createOrderSchema = z.object({
  paymentMethod: z.literal('cash'),
  items: z.array(
    z.object({
      productId: z.coerce.number().int().positive(),
      qty: z.coerce.number().int().positive(),
      schedDate: z.string().regex(datePattern).optional().or(z.literal('')),
      schedTime: z.string().regex(timePattern).optional().or(z.literal('')),
    }),
  ).min(1),
});

export const orderStatusSchema = z.object({
  status: z.enum(['confirmed', 'preparing', 'ready', 'delivering', 'delivered', 'cancelled']),
});

export const ratingSchema = z.object({
  role: z.enum(['buyer', 'seller']),
  rating: z.coerce.number().int().min(1).max(5),
  comment: z.string().trim().max(2000).optional().default(''),
});

export type CreateOrderInput = z.infer<typeof createOrderSchema>;
export type OrderStatusInput = z.infer<typeof orderStatusSchema>;
export type RatingInput = z.infer<typeof ratingSchema>;
