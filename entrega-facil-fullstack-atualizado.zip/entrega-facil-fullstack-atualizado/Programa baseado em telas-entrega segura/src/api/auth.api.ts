import type { RegisterData, User } from '../domain/types';
import { apiFetch, setAuthToken } from './http';

export interface AuthResponse {
  user: User;
  token: string;
}

export async function loginApi(email: string, password: string): Promise<AuthResponse> {
  const response = await apiFetch<AuthResponse>('/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email, password }),
  });
  setAuthToken(response.token);
  return response;
}

export async function registerApi(data: RegisterData): Promise<AuthResponse> {
  const response = await apiFetch<AuthResponse>('/auth/register', {
    method: 'POST',
    body: JSON.stringify({
      ...data,
      condominiumId: Number(data.condominiumId),
    }),
  });
  setAuthToken(response.token);
  return response;
}

export function getCurrentUserApi() {
  return apiFetch<{ user: User }>('/auth/me');
}

export function updateCurrentUserApi(data: { name: string; phone?: string }) {
  return apiFetch<{ user: User }>('/auth/me', {
    method: 'PATCH',
    body: JSON.stringify(data),
  });
}

export async function deleteAccountApi() {
  await apiFetch<void>('/auth/me', { method: 'DELETE' });
  setAuthToken(null);
}

export function logoutApi() {
  setAuthToken(null);
}
