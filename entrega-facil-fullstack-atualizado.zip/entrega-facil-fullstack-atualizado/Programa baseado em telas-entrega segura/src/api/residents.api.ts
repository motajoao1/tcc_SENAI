import { apiFetch } from './http';

export interface ResidentValidationResponse {
  validated: boolean;
  message?: string;
  block?: string;
  apartment?: string;
}

export function validateResidentApi() {
  return apiFetch<ResidentValidationResponse>(
    '/residents/validate',
    {
      method: 'POST',
    },
  );
}

export interface UpdateResidentAddressData {
  condominiumId: string;
  block: string;
  apartment: string;
}

export interface UpdateResidentAddressResponse {
  condominiumId: string;
  block: string;
  apartment: string;
  validated: boolean;
}

export function updateResidentAddressApi(
  data: UpdateResidentAddressData,
) {
  return apiFetch<UpdateResidentAddressResponse>(
    '/residents/address',
    {
      method: 'PUT',

      body: JSON.stringify({
        condominiumId: Number(data.condominiumId),
        block: data.block,
        apartment: data.apartment,
      }),
    },
  );
}