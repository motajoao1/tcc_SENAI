import type { Product, User } from '../domain/types';
import { apiFetch } from './http';

export interface ProductsResponse {
  products: Product[];
  users: User[];
}

function productPayload(product: Omit<Product, 'id'> | Product) {
  return {
    name: product.name,
    description: product.description,
    price: product.price,
    cost: product.cost ?? null,
    stock: product.stock,
    category: product.category,
    img: product.img,
    type: product.type,
    available: product.available,
    duration: product.duration ?? null,
    availableDays: product.availableDays ?? [],
    availableStart: product.availableStart ?? null,
    availableEnd: product.availableEnd ?? null,
  };
}

export function getProductsApi() {
  return apiFetch<ProductsResponse>('/products');
}

export function createProductApi(product: Omit<Product, 'id'>) {
  return apiFetch<{ product: Product }>('/products', {
    method: 'POST',
    body: JSON.stringify(productPayload(product)),
  });
}

export function updateProductApi(id: string, product: Product) {
  return apiFetch<{ product: Product }>(`/products/${id}`, {
    method: 'PUT',
    body: JSON.stringify(productPayload(product)),
  });
}

export function deleteProductApi(id: string) {
  return apiFetch<void>(`/products/${id}`, { method: 'DELETE' });
}
