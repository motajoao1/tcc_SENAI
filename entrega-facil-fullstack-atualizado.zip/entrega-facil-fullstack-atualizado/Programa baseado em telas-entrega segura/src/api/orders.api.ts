import type { CartItem, Order, OrderStatus, User } from '../domain/types';
import { apiFetch } from './http';

export interface OrdersResponse {
  orders: Order[];
  users: User[];
}

export function getOrdersApi() {
  return apiFetch<OrdersResponse>('/orders');
}

export function createOrderApi(items: CartItem[]) {
  return apiFetch<{ order: Order }>('/orders', {
    method: 'POST',
    body: JSON.stringify({
      paymentMethod: 'cash',
      items: items.map((item) => ({
        productId: Number(item.product.id),
        qty: item.qty,
        schedDate: item.schedDate || '',
        schedTime: item.schedTime || '',
      })),
    }),
  });
}

export function updateOrderStatusApi(orderId: string, status: OrderStatus) {
  return apiFetch<{ order: Order }>(`/orders/${orderId}/status`, {
    method: 'PATCH',
    body: JSON.stringify({ status }),
  });
}

export function confirmReceiptApi(orderId: string) {
  return apiFetch<{ order: Order }>(`/orders/${orderId}/confirm-receipt`, {
    method: 'POST',
  });
}

export function rateOrderApi(
  orderId: string,
  role: 'buyer' | 'seller',
  rating: number,
  comment = '',
) {
  return apiFetch<{ order: Order }>(`/orders/${orderId}/ratings`, {
    method: 'POST',
    body: JSON.stringify({ role, rating, comment }),
  });
}
