import { apiFetch } from './http';
import type { Condominium } from '../domain/types';

interface CondominiumApiResponse {
  id: number;
  nome: string;
  endereco: string;
  hora_inicio: number;
  hora_fim: number;
  dias_permitidos: number[];
}

export async function getCondominiums(): Promise<Condominium[]> {
  const response =
    await apiFetch<CondominiumApiResponse[]>('/condominiums');

  return response.map((item) => ({
    id: String(item.id),
    name: item.nome,
    address: item.endereco,
    allowedHours: {
      start: item.hora_inicio,
      end: item.hora_fim,
    },
    allowedDays: item.dias_permitidos,
  }));
}