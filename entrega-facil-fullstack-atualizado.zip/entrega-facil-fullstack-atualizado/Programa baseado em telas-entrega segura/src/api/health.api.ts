import { apiFetch } from './http';

export interface HealthResponse {
  status: string;
  application: string;
  database: string;
  timestamp?: string;
}

export function getHealth() {
  return apiFetch<HealthResponse>('/health');
}   