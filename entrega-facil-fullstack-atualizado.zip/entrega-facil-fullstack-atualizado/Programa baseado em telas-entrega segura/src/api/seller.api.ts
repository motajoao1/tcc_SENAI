import type { SellerProfile, User } from '../domain/types';
import { apiFetch } from './http';

export function enableSellerApi(profile: SellerProfile) {
  return apiFetch<{ user: User }>('/seller/profile', {
    method: 'PUT',
    body: JSON.stringify(profile),
  });
}
