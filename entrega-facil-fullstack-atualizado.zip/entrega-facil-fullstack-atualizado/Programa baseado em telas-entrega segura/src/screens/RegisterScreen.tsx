import { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  PageHeader,
  ScrollArea,
  Shell,
} from '../components/layout/Shell';
import { Button } from '../components/ui/Button';
import {
  Field,
  SelectField,
} from '../components/ui/Field';
import { Modal } from '../components/ui/Modal';
import { PrivacyPolicyText } from './PrivacyScreen';
import {
  maskCPF,
  validateCPF,
  validateEmail,
} from '../utils/formatters';

const TOTAL_STEPS = 3;

export function RegisterScreen() {
  const { state, actions } = useApp();

  const reviewResident =
    state.screenParams.reviewResident === true &&
    Boolean(state.currentUser) &&
    !state.currentUser?.validated;

  const [step, setStep] = useState(1);

  const [name, setName] = useState('');
  const [cpf, setCpf] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] =
    useState('');

  const [condominiumId, setCondominiumId] =
    useState(
      reviewResident
        ? state.currentUser?.condominiumId ?? ''
        : '',
    );

  const [block, setBlock] = useState(
    reviewResident
      ? state.currentUser?.block ?? ''
      : '',
  );

  const [apartment, setApartment] = useState(
    reviewResident
      ? state.currentUser?.apartment ?? ''
      : '',
  );

  const [acceptedTerms, setAcceptedTerms] =
    useState(false);

  const [errors, setErrors] = useState<
    Record<string, string>
  >({});

  const [formError, setFormError] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPolicy, setShowPolicy] = useState(false);

  const validateStep = (
    target: number,
  ): boolean => {
    const next: Record<string, string> = {};

    if (target === 1) {
      if (
        name.trim().split(' ').filter(Boolean).length <
        2
      ) {
        next.name = 'Informe nome e sobrenome';
      }

      if (!validateCPF(cpf)) {
        next.cpf = 'CPF inválido';
      }

      if (!validateEmail(email)) {
        next.email = 'Informe um e-mail válido';
      }

      if (password.length < 6) {
        next.password =
          'A senha deve ter ao menos 6 caracteres';
      }

      if (password !== confirmPassword) {
        next.confirmPassword =
          'As senhas não coincidem';
      }
    }

    if (target === 2) {
      if (!condominiumId) {
        next.condominiumId =
          'Selecione o seu condomínio';
      }

      if (!block.trim()) {
        next.block = 'Informe o bloco ou torre';
      }

      if (!apartment.trim()) {
        next.apartment = 'Informe o apartamento';
      }
    }

    if (target === 3) {
      if (!acceptedTerms) {
        next.accepted =
          'É necessário aceitar os termos para continuar';
      }
    }

    setErrors(next);

    return Object.keys(next).length === 0;
  };

  const goNext = () => {
    if (!validateStep(step)) return;

    setErrors({});
    setStep((current) => current + 1);
  };

  const submit = async () => {
    if (!validateStep(3)) return;

    setFormError('');
    setLoading(true);

    try {
      await actions.register({
        name,
        email,
        password,
        cpf,
        condominiumId,
        block,
        apartment,
      });
    } catch (error) {
      setFormError(
        error instanceof Error
          ? error.message
          : 'Não foi possível criar a conta.',
      );
    } finally {
      setLoading(false);
    }
  };

  const back = () => {
    if (step === 1) {
      actions.navigate('welcome');
      return;
    }

    setStep((current) => current - 1);
  };

  const submitAddressReview = async () => {
    const next: Record<string, string> = {};

    if (!condominiumId) {
      next.condominiumId =
        'Selecione o seu condomínio';
    }

    if (!block.trim()) {
      next.block = 'Informe o bloco ou torre';
    }

    if (!apartment.trim()) {
      next.apartment = 'Informe o apartamento';
    }

    setErrors(next);
    setFormError('');

    if (Object.keys(next).length > 0) {
      return;
    }

    setLoading(true);

    try {
      await actions.updateResidentAddress({
        condominiumId,
        block,
        apartment,
      });
    } catch (error) {
      setFormError(
        error instanceof Error
          ? error.message
          : 'Não foi possível atualizar os dados.',
      );
    } finally {
      setLoading(false);
    }
  };

  // =========================================================
  // MODO DE REVISÃO DOS DADOS DO MORADOR
  // =========================================================

  if (reviewResident) {
    return (
      <Shell>
        <PageHeader
          title="Revisar moradia"
          subtitle="Corrija os dados do seu condomínio"
          onBack={() =>
            actions.navigate('validation')
          }
        />

        <ScrollArea className="px-4 py-5 md:px-6">
          <div className="mx-auto flex w-full max-w-[520px] flex-col gap-4 rounded-2xl bg-white p-5 shadow-sm ring-1 ring-gray-100">
            <h2 className="text-base font-bold text-gray-900">
              Onde você mora
            </h2>

            <p className="text-sm text-gray-600">
              Revise os dados abaixo. Depois de
              salvar, faremos uma nova validação da
              sua moradia.
            </p>

            <SelectField
              id="review-condo"
              label="Condomínio"
              placeholder="Selecione o condomínio"
              value={condominiumId}
              onChange={setCondominiumId}
              options={state.condominiums.map(
                (condominium) => ({
                  value: condominium.id,
                  label: condominium.name,
                }),
              )}
              error={errors.condominiumId}
              required
            />

            <Field
              id="review-block"
              label="Bloco / Torre"
              placeholder="Ex: A"
              value={block}
              onChange={setBlock}
              error={errors.block}
              required
            />

            <Field
              id="review-apartment"
              label="Apartamento"
              placeholder="Ex: 201"
              value={apartment}
              onChange={setApartment}
              inputMode="numeric"
              error={errors.apartment}
              required
            />

            {formError && (
              <p
                role="alert"
                className="text-sm font-medium text-red-600"
              >
                {formError}
              </p>
            )}

            <Button
              fullWidth
              loading={loading}
              onClick={submitAddressReview}
            >
              Salvar e validar novamente
            </Button>
          </div>
        </ScrollArea>
      </Shell>
    );
  }

  // =========================================================
  // CADASTRO NORMAL
  // =========================================================

  return (
    <Shell>
      <PageHeader
        title="Criar conta"
        subtitle={`Passo ${step} de ${TOTAL_STEPS}`}
        onBack={back}
      />

      <div className="shrink-0 bg-white px-4 pb-4 md:px-6">
        <div
          className="flex gap-2"
          role="progressbar"
          aria-valuenow={step}
          aria-valuemin={1}
          aria-valuemax={TOTAL_STEPS}
          aria-label="Progresso do cadastro"
        >
          {[1, 2, 3].map((item) => (
            <span
              key={item}
              className={`h-2 flex-1 rounded-full ${
                item <= step
                  ? 'bg-[#2563EB]'
                  : 'bg-gray-200'
              }`}
            />
          ))}
        </div>
      </div>

      <ScrollArea className="px-4 py-5 md:px-6">
        <div className="mx-auto flex w-full max-w-[520px] flex-col gap-4 rounded-2xl bg-white p-5 shadow-sm ring-1 ring-gray-100">
          {step === 1 && (
            <>
              <h2 className="text-base font-bold text-gray-900">
                Seus dados
              </h2>

              <Field
                id="reg-name"
                label="Nome completo"
                placeholder="Maria Silva"
                value={name}
                onChange={setName}
                error={errors.name}
                required
              />

              <Field
                id="reg-cpf"
                label="CPF"
                placeholder="000.000.000-00"
                value={cpf}
                onChange={(value) =>
                  setCpf(maskCPF(value))
                }
                maxLength={14}
                inputMode="numeric"
                error={errors.cpf}
                required
              />

              <Field
                id="reg-email"
                label="E-mail"
                type="email"
                inputMode="email"
                placeholder="seu@email.com"
                value={email}
                onChange={setEmail}
                error={errors.email}
                required
              />

              <Field
                id="reg-password"
                label="Senha"
                type="password"
                placeholder="Mínimo 6 caracteres"
                value={password}
                onChange={setPassword}
                error={errors.password}
                required
              />

              <Field
                id="reg-confirm"
                label="Confirmar senha"
                type="password"
                placeholder="Repita a senha"
                value={confirmPassword}
                onChange={setConfirmPassword}
                error={errors.confirmPassword}
                required
              />
            </>
          )}

          {step === 2 && (
            <>
              <h2 className="text-base font-bold text-gray-900">
                Onde você mora
              </h2>

              <SelectField
                id="reg-condo"
                label="Condomínio"
                placeholder="Selecione o condomínio"
                value={condominiumId}
                onChange={setCondominiumId}
                options={state.condominiums.map(
                  (condominium) => ({
                    value: condominium.id,
                    label: condominium.name,
                  }),
                )}
                error={errors.condominiumId}
                required
              />

              <Field
                id="reg-block"
                label="Bloco / Torre"
                placeholder="Ex: A"
                value={block}
                onChange={setBlock}
                error={errors.block}
                required
              />

              <Field
                id="reg-apartment"
                label="Apartamento"
                placeholder="Ex: 201"
                value={apartment}
                onChange={setApartment}
                inputMode="numeric"
                error={errors.apartment}
                required
              />

              <p className="text-sm text-gray-500">
                Usamos essas informações para validar
                sua moradia e mostrar apenas anúncios
                do seu condomínio.
              </p>

              <p className="rounded-xl bg-blue-50 p-3 text-xs text-blue-800">
                Para demonstração: Solar — Bloco A,
                apto 201; Parque Verde — Torre 1,
                apto 703.
              </p>
            </>
          )}

          {step === 3 && (
            <>
              <h2 className="text-base font-bold text-gray-900">
                Termos e privacidade
              </h2>

              <div className="rounded-xl bg-gray-50 p-4 text-sm text-gray-600">
                Seus dados são usados apenas para
                validar sua moradia, intermediar
                pedidos entre vizinhos e enviar
                notificações do aplicativo. Você pode
                solicitar a exclusão a qualquer
                momento.
              </div>

              <label
                htmlFor="reg-terms"
                className="flex items-start gap-3 text-sm text-gray-700"
              >
                <input
                  id="reg-terms"
                  type="checkbox"
                  checked={acceptedTerms}
                  onChange={(event) =>
                    setAcceptedTerms(
                      event.target.checked,
                    )
                  }
                  className="mt-0.5 h-5 w-5 shrink-0 rounded border-gray-300 text-[#2563EB] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
                />

                <span>
                  Li e concordo com os Termos de Uso e
                  a{' '}
                  <button
                    type="button"
                    onClick={() =>
                      setShowPolicy(true)
                    }
                    className="font-semibold text-[#2563EB] underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
                  >
                    Política de Privacidade
                  </button>
                  .
                </span>
              </label>

              {errors.accepted && (
                <p
                  role="alert"
                  className="text-sm font-medium text-red-600"
                >
                  {errors.accepted}
                </p>
              )}
            </>
          )}

          {formError && (
            <p
              role="alert"
              className="text-sm font-medium text-red-600"
            >
              {formError}
            </p>
          )}

          <div className="mt-2 flex gap-3">
            {step > 1 && (
              <Button
                variant="secondary"
                fullWidth
                onClick={() =>
                  setStep(
                    (current) => current - 1,
                  )
                }
              >
                Anterior
              </Button>
            )}

            {step < TOTAL_STEPS ? (
              <Button
                fullWidth
                onClick={goNext}
              >
                Próximo
              </Button>
            ) : (
              <Button
                fullWidth
                loading={loading}
                onClick={submit}
              >
                Criar conta
              </Button>
            )}
          </div>
        </div>
      </ScrollArea>

      <Modal
        open={showPolicy}
        title="Política de Privacidade"
        onClose={() => setShowPolicy(false)}
      >
        <PrivacyPolicyText />
      </Modal>
    </Shell>
  );
}