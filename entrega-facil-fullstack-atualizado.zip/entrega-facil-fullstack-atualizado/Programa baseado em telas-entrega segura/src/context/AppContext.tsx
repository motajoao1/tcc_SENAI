import { useCallback, useEffect, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import type {
  CartItem,
  Condominium,
  Order,
  OrderStatus,
  PaymentMethod,
  Product,
  RegisterData,
  Screen,
  SellerProfile,
  User,
} from '../domain/types';
import { cartService, type AddToCartResult } from '../services/cartService';
import { validateCartSchedules } from '../services/scheduleService';
import { AppContext } from './AppContextCore';
import { getCondominiums } from '../api/condominiums.api';
import {
  deleteAccountApi,
  getCurrentUserApi,
  loginApi,
  logoutApi,
  registerApi,
  updateCurrentUserApi,
} from '../api/auth.api';
import { getAuthToken } from '../api/http';
import {
  updateResidentAddressApi,
  validateResidentApi,
} from '../api/residents.api';
import { enableSellerApi } from '../api/seller.api';
import {
  createProductApi,
  deleteProductApi,
  getProductsApi,
  updateProductApi,
} from '../api/products.api';
import {
  confirmReceiptApi,
  createOrderApi,
  getOrdersApi,
  rateOrderApi,
  updateOrderStatusApi,
} from '../api/orders.api';

export { useApp } from './AppContextCore';

export type ActiveMode = 'buyer' | 'seller';

export interface AppState {
  currentUser: User | null;
  currentScreen: Screen;
  screenParams: Record<string, unknown>;
  products: Product[];
  orders: Order[];
  cart: CartItem[];
  lastOrder: Order | null;
  condominiums: Condominium[];
  users: User[];
  activeMode: ActiveMode;
  pendingCartItem: CartItem | null;
  checkoutError: string;
}

export interface AppActions {
  navigate: (screen: Screen, params?: Record<string, unknown>) => void;
  login: (email: string, password: string) => Promise<User>;
  register: (data: RegisterData) => Promise<User>;
  logout: () => void;
  restartRegistration: () => void;
  updateResidentAddress: (data: {
    condominiumId: string;
    block: string;
    apartment: string;
  }) => Promise<void>;
  validateCurrentResident: () => Promise<'approved' | 'rejected'>;
  setActiveMode: (mode: ActiveMode) => void;
  addToCart: (
    product: Product,
    qty?: number,
    schedule?: Pick<CartItem, 'schedDate' | 'schedTime'>,
  ) => AddToCartResult;
  keepCurrentCart: () => void;
  replaceCartWithPendingItem: () => void;
  removeFromCart: (productId: string) => void;
  updateCartQty: (productId: string, qty: number) => void;
  updateCartSchedule: (productId: string, date: string, time: string) => void;
  clearCart: () => void;
  placeOrder: (paymentMethod: PaymentMethod) => Promise<Order | null>;
  updateOrderStatus: (orderId: string, status: OrderStatus) => Promise<void>;
  confirmReceipt: (orderId: string) => Promise<void>;
  addProduct: (product: Omit<Product, 'id'>) => Promise<Product>;
  updateProduct: (id: string, updates: Partial<Product>) => Promise<Product>;
  deleteProduct: (id: string) => Promise<void>;
  enableSeller: (sellerProfile: SellerProfile) => Promise<User>;
  rateOrder: (
    orderId: string,
    role: 'buyer' | 'seller',
    rating: number,
    comment?: string,
  ) => Promise<void>;
  updateCurrentUser: (updates: Partial<User> & { phone?: string }) => Promise<void>;
  deleteAccount: () => Promise<void>;
  refreshMarketplace: () => Promise<void>;
}

export interface AppContextValue {
  state: AppState;
  actions: AppActions;
  condominium: Condominium | null;
  findUser: (id: string) => User | undefined;
}

const INITIAL_STATE: AppState = {
  currentUser: null,
  currentScreen: 'welcome',
  screenParams: {},
  products: [],
  orders: [],
  cart: [],
  lastOrder: null,
  condominiums: [],
  users: [],
  activeMode: 'buyer',
  pendingCartItem: null,
  checkoutError: '',
};

function mergeUsers(current: User[], incoming: User[]): User[] {
  const merged = new Map<string, User>();
  for (const user of current) merged.set(user.id, user);
  for (const user of incoming) merged.set(user.id, user);
  return [...merged.values()];
}

function replaceOrder(orders: Order[], updated: Order): Order[] {
  const found = orders.some((order) => order.id === updated.id);
  return found
    ? orders.map((order) => (order.id === updated.id ? updated : order))
    : [updated, ...orders];
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AppState>(INITIAL_STATE);

  const refreshMarketplace = useCallback(async () => {
    const [productResult, orderResult] = await Promise.allSettled([
      getProductsApi(),
      getOrdersApi(),
    ]);

    if (productResult.status === 'rejected') {
      console.error('Não foi possível carregar os produtos:', productResult.reason);
    }

    if (orderResult.status === 'rejected') {
      console.error('Não foi possível carregar os pedidos:', orderResult.reason);
    }

    setState((current) => {
      let products = current.products;
      let orders = current.orders;
      let users = current.users;

      if (productResult.status === 'fulfilled') {
        products = productResult.value.products;
        users = mergeUsers(users, productResult.value.users);
      }

      if (orderResult.status === 'fulfilled') {
        orders = orderResult.value.orders;
        users = mergeUsers(users, orderResult.value.users);
      }

      return {
        ...current,
        products,
        orders,
        users,
      };
    });
  }, []);

  useEffect(() => {
    let active = true;

    getCondominiums()
      .then((condominiums) => {
        if (!active) return;
        setState((current) => ({ ...current, condominiums }));
      })
      .catch((error) => {
        console.error('Não foi possível carregar os condomínios da API:', error);
      });

    if (getAuthToken()) {
      getCurrentUserApi()
        .then(async ({ user }) => {
          if (!active) return;
          setState((current) => ({
            ...current,
            currentUser: user,
            users: mergeUsers(current.users, [user]),
            currentScreen: user.validated ? 'catalog' : 'validation',
          }));
          if (user.validated) await refreshMarketplace();
        })
        .catch(() => {
          logoutApi();
          if (!active) return;
          setState((current) => ({ ...current, currentUser: null, currentScreen: 'welcome' }));
        });
    }

    return () => {
      active = false;
    };
  }, [refreshMarketplace]);

  const navigate = useCallback((screen: Screen, params: Record<string, unknown> = {}) => {
    setState((current) => ({ ...current, currentScreen: screen, screenParams: params }));
  }, []);

  const login = useCallback(
    async (email: string, password: string): Promise<User> => {
      const { user } = await loginApi(email, password);
      setState((current) => ({
        ...current,
        users: mergeUsers(current.users, [user]),
        currentUser: user,
        activeMode: 'buyer',
        currentScreen: user.validated ? 'catalog' : 'validation',
        screenParams: {},
        cart: [],
      }));
      if (user.validated) await refreshMarketplace();
      return user;
    },
    [refreshMarketplace],
  );

  const register = useCallback(async (data: RegisterData): Promise<User> => {
    const { user } = await registerApi(data);
    setState((current) => ({
      ...current,
      users: mergeUsers(current.users, [user]),
      currentUser: user,
      activeMode: 'buyer',
      currentScreen: 'validation',
      screenParams: {},
      cart: [],
    }));
    return user;
  }, []);

  const logout = useCallback(() => {
    logoutApi();
    setState((current) => ({
      ...current,
      currentUser: null,
      currentScreen: 'welcome',
      screenParams: {},
      products: [],
      orders: [],
      users: [],
      cart: [],
      lastOrder: null,
      activeMode: 'buyer',
    }));
  }, []);

  const restartRegistration = useCallback(() => {
    setState((current) => {
      if (!current.currentUser || current.currentUser.validated) return current;
      return {
        ...current,
        currentScreen: 'register',
        screenParams: { reviewResident: true },
        cart: [],
        lastOrder: null,
        pendingCartItem: null,
        checkoutError: '',
      };
    });
  }, []);

  const updateResidentAddress = useCallback(
    async (data: { condominiumId: string; block: string; apartment: string }) => {
      const updated = await updateResidentAddressApi(data);
      setState((current) => {
        if (!current.currentUser) return current;
        const updatedUser: User = {
          ...current.currentUser,
          condominiumId: updated.condominiumId,
          block: updated.block,
          apartment: updated.apartment,
          validated: false,
        };
        return {
          ...current,
          currentUser: updatedUser,
          users: mergeUsers(current.users, [updatedUser]),
          currentScreen: 'validation',
          screenParams: {},
        };
      });
    },
    [],
  );

  const validateCurrentResident = useCallback(async (): Promise<'approved' | 'rejected'> => {
    const result = await validateResidentApi();
    if (!result.validated) return 'rejected';

    const { user } = await getCurrentUserApi();
    setState((current) => ({
      ...current,
      currentUser: user,
      users: mergeUsers(current.users, [user]),
    }));
    await refreshMarketplace();
    return 'approved';
  }, [refreshMarketplace]);

  const setActiveMode = useCallback((mode: ActiveMode) => {
    setState((current) => ({
      ...current,
      activeMode: mode,
      currentScreen: mode === 'seller' ? 'seller-dashboard' : 'catalog',
      screenParams: {},
    }));
  }, []);

  const addToCart = useCallback(
    (
      product: Product,
      qty = 1,
      schedule?: Pick<CartItem, 'schedDate' | 'schedTime'>,
    ): AddToCartResult => {
      const result = cartService.add(state.cart, product, qty, schedule);
      setState((current) => ({
        ...current,
        cart: result.cart,
        pendingCartItem: result.pendingItem ?? null,
        checkoutError:
          result.result === 'unavailable'
            ? `Quantidade indisponível. Restam ${product.stock} unidades.`
            : '',
      }));
      return result.result;
    },
    [state.cart],
  );

  const keepCurrentCart = useCallback(() => {
    setState((current) => ({ ...current, pendingCartItem: null }));
  }, []);

  const replaceCartWithPendingItem = useCallback(() => {
    setState((current) => {
      if (!current.pendingCartItem) return current;
      return {
        ...current,
        cart: [current.pendingCartItem],
        pendingCartItem: null,
        checkoutError: '',
      };
    });
  }, []);

  const removeFromCart = useCallback((productId: string) => {
    setState((current) => ({
      ...current,
      cart: current.cart.filter((item) => item.product.id !== productId),
    }));
  }, []);

  const updateCartQty = useCallback((productId: string, qty: number) => {
    setState((current) => {
      const product = current.products.find((entry) => entry.id === productId);
      if (qty > (product?.stock ?? 0)) {
        return {
          ...current,
          checkoutError: `Quantidade indisponível. Restam ${product?.stock ?? 0} unidades.`,
        };
      }
      return {
        ...current,
        checkoutError: '',
        cart:
          qty <= 0
            ? current.cart.filter((item) => item.product.id !== productId)
            : current.cart.map((item) =>
                item.product.id === productId ? { ...item, qty } : item,
              ),
      };
    });
  }, []);

  const updateCartSchedule = useCallback((productId: string, date: string, time: string) => {
    setState((current) => ({
      ...current,
      cart: current.cart.map((item) =>
        item.product.id === productId ? { ...item, schedDate: date, schedTime: time } : item,
      ),
    }));
  }, []);

  const clearCart = useCallback(() => {
    setState((current) => ({
      ...current,
      cart: [],
      pendingCartItem: null,
      checkoutError: '',
    }));
  }, []);

  const placeOrder = useCallback(
    async (_paymentMethod: PaymentMethod): Promise<Order | null> => {
      const { currentUser, cart } = state;
      if (!currentUser || cart.length === 0) return null;

      const sellers = new Set(cart.map((item) => item.product.sellerId));
      const currentCondominium =
        state.condominiums.find((item) => item.id === currentUser.condominiumId) ?? null;
      const scheduleErrors = validateCartSchedules(cart, currentCondominium);

      if (sellers.size !== 1 || Object.keys(scheduleErrors).length > 0) {
        setState((current) => ({
          ...current,
          checkoutError:
            sellers.size !== 1
              ? 'O carrinho deve conter itens de apenas um vendedor.'
              : Object.values(scheduleErrors)[0],
        }));
        return null;
      }

      try {
        const { order } = await createOrderApi(cart);
        const productData = await getProductsApi();
        setState((current) => ({
          ...current,
          orders: replaceOrder(current.orders, order),
          products: productData.products,
          users: mergeUsers(current.users, productData.users),
          cart: [],
          lastOrder: order,
          checkoutError: '',
        }));
        return order;
      } catch (error) {
        setState((current) => ({
          ...current,
          checkoutError: error instanceof Error ? error.message : 'Não foi possível criar o pedido.',
        }));
        return null;
      }
    },
    [state],
  );

  const updateOrderStatus = useCallback(async (orderId: string, status: OrderStatus) => {
    const { order } = await updateOrderStatusApi(orderId, status);
    const productData = status === 'cancelled' ? await getProductsApi() : null;
    setState((current) => ({
      ...current,
      orders: replaceOrder(current.orders, order),
      lastOrder: current.lastOrder?.id === order.id ? order : current.lastOrder,
      ...(productData
        ? {
            products: productData.products,
            users: mergeUsers(current.users, productData.users),
          }
        : {}),
    }));
  }, []);

  const confirmReceipt = useCallback(async (orderId: string) => {
    const { order } = await confirmReceiptApi(orderId);
    setState((current) => ({
      ...current,
      orders: replaceOrder(current.orders, order),
      lastOrder: current.lastOrder?.id === order.id ? order : current.lastOrder,
    }));
  }, []);

  const addProduct = useCallback(async (draft: Omit<Product, 'id'>): Promise<Product> => {
    const { product } = await createProductApi(draft);
    setState((current) => ({ ...current, products: [product, ...current.products] }));
    return product;
  }, []);

  const updateProduct = useCallback(
    async (id: string, updates: Partial<Product>): Promise<Product> => {
      const existing = state.products.find((product) => product.id === id);
      if (!existing) throw new Error('Produto não encontrado.');
      const { product } = await updateProductApi(id, { ...existing, ...updates });
      setState((current) => ({
        ...current,
        products: current.products.map((item) => (item.id === id ? product : item)),
      }));
      return product;
    },
    [state.products],
  );

  const deleteProduct = useCallback(async (id: string) => {
    await deleteProductApi(id);
    setState((current) => ({
      ...current,
      products: current.products.filter((product) => product.id !== id),
    }));
  }, []);

  const enableSeller = useCallback(async (sellerProfile: SellerProfile): Promise<User> => {
    const { user } = await enableSellerApi(sellerProfile);
    setState((current) => ({
      ...current,
      currentUser: user,
      users: mergeUsers(current.users, [user]),
    }));
    return user;
  }, []);

  const rateOrder = useCallback(
    async (
      orderId: string,
      role: 'buyer' | 'seller',
      rating: number,
      comment = '',
    ) => {
      const { order } = await rateOrderApi(orderId, role, rating, comment);
      const [productData, { user }] = await Promise.all([
        getProductsApi(),
        getCurrentUserApi(),
      ]);
      setState((current) => ({
        ...current,
        orders: replaceOrder(current.orders, order),
        products: productData.products,
        currentUser: user,
        users: mergeUsers(current.users, [...productData.users, user]),
      }));
    },
    [],
  );

  const updateCurrentUser = useCallback(
    async (updates: Partial<User> & { phone?: string }) => {
      const current = state.currentUser;
      if (!current) return;
      const { user } = await updateCurrentUserApi({
        name: updates.name ?? current.name,
        ...(updates.phone !== undefined ? { phone: updates.phone } : {}),
      });
      setState((snapshot) => ({
        ...snapshot,
        currentUser: user,
        users: mergeUsers(snapshot.users, [user]),
      }));
    },
    [state.currentUser],
  );

  const deleteAccount = useCallback(async () => {
    await deleteAccountApi();
    setState((current) => ({
      ...current,
      currentUser: null,
      currentScreen: 'welcome',
      screenParams: {},
      products: [],
      orders: [],
      users: [],
      cart: [],
      lastOrder: null,
      activeMode: 'buyer',
    }));
  }, []);

  const actions = useMemo<AppActions>(
    () => ({
      navigate,
      login,
      register,
      logout,
      restartRegistration,
      updateResidentAddress,
      validateCurrentResident,
      setActiveMode,
      addToCart,
      keepCurrentCart,
      replaceCartWithPendingItem,
      removeFromCart,
      updateCartQty,
      updateCartSchedule,
      clearCart,
      placeOrder,
      updateOrderStatus,
      confirmReceipt,
      addProduct,
      updateProduct,
      deleteProduct,
      enableSeller,
      rateOrder,
      updateCurrentUser,
      deleteAccount,
      refreshMarketplace,
    }),
    [
      navigate,
      login,
      register,
      logout,
      restartRegistration,
      updateResidentAddress,
      validateCurrentResident,
      setActiveMode,
      addToCart,
      keepCurrentCart,
      replaceCartWithPendingItem,
      removeFromCart,
      updateCartQty,
      updateCartSchedule,
      clearCart,
      placeOrder,
      updateOrderStatus,
      confirmReceipt,
      addProduct,
      updateProduct,
      deleteProduct,
      enableSeller,
      rateOrder,
      updateCurrentUser,
      deleteAccount,
      refreshMarketplace,
    ],
  );

  const condominium = useMemo(
    () =>
      state.currentUser
        ? state.condominiums.find((item) => item.id === state.currentUser?.condominiumId) ?? null
        : null,
    [state.currentUser, state.condominiums],
  );

  const findUser = useCallback(
    (id: string) => state.users.find((user) => user.id === id),
    [state.users],
  );

  const value = useMemo<AppContextValue>(
    () => ({ state, actions, condominium, findUser }),
    [state, actions, condominium, findUser],
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}
